"""Run public-data end-to-end checks; no EP data are read or transmitted."""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'web'))
from analysis import run_analysis,read_table,make_report
from sklearn.datasets import load_diabetes,load_wine
import pandas as pd
OUT=ROOT/'validation/results';OUT.mkdir(parents=True,exist_ok=True)
records=[]
cases=[('synthetic_regression',pd.read_csv(ROOT/'web/public/samples/example_regression.csv'),'regression','target','group'),
       ('iris_classification',pd.read_csv(ROOT/'web/public/samples/example_classification.csv'),'classification','target',''),
       ('wine_classification',load_wine(as_frame=True).frame,'classification','target','')]
for name,df,task,target,group in cases:
    print('START',name,flush=True)
    if (OUT/name/'summary.json').exists():
        summary=json.loads((OUT/name/'summary.json').read_text(encoding='utf8'))
        make_report(summary,OUT/name)
    else:
        summary=run_analysis(df,dict(task=task,target=target,group=group,mode='auto',budget='interactive',seed=728),OUT/name,lambda s:print(s,flush=True))
    records.append(dict(dataset=name,task=task,train_rows=summary['train_rows'],test_rows=summary['test_rows'],metrics=summary['metrics'],seconds=summary['seconds']))
    (OUT/'integration_summary.json').write_text(json.dumps(records,indent=2),encoding='utf8')
print('DONE',json.dumps(records),flush=True)

"""本机分析流水线：输入检查、实体划分、PARENA 训练、诊断图和 PDF 报告。

每次任务使用独立目录。原始数据、模型中间结果和报告均保留在本机。
"""
from pathlib import Path
import hashlib, json, time, sys, io, zipfile, platform
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.model_selection import GroupShuffleSplit, StratifiedGroupKFold
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score,accuracy_score,balanced_accuracy_score,f1_score,log_loss,confusion_matrix,roc_auc_score
from catboost import CatBoostRegressor,CatBoostClassifier,Pool

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'package/src'))
from parena import PARENARegressor,PARENAClassifier
from parena.preprocessing import NumericPreprocessor
from parena.study import load_policy

from matplotlib import font_manager
available_fonts={f.name for f in font_manager.fontManager.ttflist}
plot_fonts=[f for f in ['Arial','Microsoft YaHei','DejaVu Sans'] if f in available_fonts]
plt.rcParams.update({'font.family':plot_fonts,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','figure.dpi':130,'savefig.dpi':170})
COLORS=['#14685e','#e5a653','#536ab3','#b66782','#83a59d']


def read_table(data, filename):
    """读取 CSV 或 XLSX 首个工作表；限制体积和解压后大小，不执行公式或宏。"""
    if len(data)>12*1024*1024:raise ValueError('File exceeds 12 MB')
    ext=Path(filename).suffix.lower()
    if ext=='.csv':
        try:df=pd.read_csv(io.BytesIO(data),encoding='utf-8-sig')
        except UnicodeDecodeError:df=pd.read_csv(io.BytesIO(data),encoding='gb18030')
    elif ext=='.xlsx':
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if sum(a.file_size for a in z.infolist())>80*1024*1024:raise ValueError('Uncompressed Excel file exceeds 80 MB')
        df=pd.read_excel(io.BytesIO(data),engine='openpyxl')
    else:raise ValueError('Use .csv or .xlsx (first sheet); macros and legacy .xls are unsupported')
    if len(df)>2000 or len(df.columns)>132:raise ValueError('CPU web limit: 2,000 rows and 128 feature columns plus metadata')
    if not len(df) or df.columns.duplicated().any():raise ValueError('Empty table or duplicate column names')
    df.columns=[str(c) for c in df.columns]
    return df


def inspect_table(df):
    """给网页返回列名、类型和小型预览；数据只通过回环地址传输。"""
    return dict(rows=len(df),columns=[dict(name=c,numeric=bool(pd.api.types.is_numeric_dtype(df[c])),missing=int(df[c].isna().sum())) for c in df.columns],
                preview=json.loads(df.head(5).to_json(orient='records')))


def quick_policy():
    """交互预算：缩小固定候选池，清楚区分完整 0.4.0 回归候选池。"""
    p=load_policy();p['pool']=[p['pool'][0],p['pool'][1]]
    for c in p['pool']:
        c['anchor_reliability']=False
        if c['model']['kind']=='cat':c['model']['iterations']=160
    for key in p['baseline_pools']:
        p['baseline_pools'][key]=[c for c in p['baseline_pools'][key] if c['model']['kind'] in ['et','cat']][:2]
    p['version']='PARENA 0.4.1 interactive CPU pool'
    return p


def save_figure(fig,name,folder,caption,figures):
    """保存可下载 PNG/PDF，以及图的用途说明。"""
    fig.tight_layout(pad=1.5)
    fig.savefig(folder/f'{name}.png',bbox_inches='tight')
    fig.savefig(folder/f'{name}.pdf',bbox_inches='tight')
    (folder/f'{name}.txt').write_text(caption,encoding='utf8')
    figures.append(dict(name=name,caption=caption));plt.close(fig)


def run_analysis(df,options,folder,progress=lambda message:None):
    """完成一次固定分组留出评估；返回指标、图表及处理记录的清单。"""
    start=time.perf_counter();folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    target=options.get('target');task=options.get('task','regression');mode=options.get('mode','core')
    if target not in df:raise ValueError('Choose an existing target column')
    if task not in ['regression','classification']:raise ValueError('Choose regression or classification')
    seed=int(options.get('seed',728))
    if not 0<=seed<2**31:raise ValueError('Seed must be between 0 and 2147483647')
    smiles=options.get('smiles') or None;group_col=options.get('group') or None
    if group_col and group_col not in df:raise ValueError('Group column is missing')
    if target in [smiles,group_col]:raise ValueError('Target must differ from SMILES and group columns')
    progress('Validating features and entity groups')
    if smiles:
        from parena.chemistry import kpi64,identity,FEATURE_NAMES
        from rdkit import Chem
        if smiles not in df:raise ValueError('SMILES column is missing')
        vals=[];ident=[];bad=[]
        for i,s in enumerate(df[smiles]):
            try:
                molecule=Chem.MolFromSmiles(str(s))
                if molecule is None or any(a.GetSymbol() not in {'H','C','N','O','F','Si','P','S','Cl','Br','I'} for a in molecule.GetAtoms()):raise ValueError('Unsupported structure/element')
                vals.append(kpi64(str(s)));ident.append(identity(str(s)))
            except Exception:bad.append(i+2)
        if bad:raise ValueError('Invalid SMILES or unsupported KPI64 element at spreadsheet rows: '+str(bad[:20])+'. KPI atomic lookups support H/C/N/O/F/Si/P/S/Cl/Br/I; use appropriate supplied descriptors for other elements.')
        X=np.array(vals);names=FEATURE_NAMES.copy();g=np.array(ident)
        # Conservative union of chemical identity and user-supplied related-experiment groups.
        if group_col:
            if df[group_col].isna().any():raise ValueError('Group IDs cannot be missing')
            g=union_groups(g,df[group_col].astype(str).to_numpy())
    else:
        names=options.get('features') or [c for c in df if c not in [target,group_col,'id','ID'] and pd.api.types.is_numeric_dtype(df[c])]
        if not names or target in names or group_col in names or len(names)!=len(set(names)):raise ValueError('Select numeric features; exclude target, group and ID columns')
        if any(c not in df or not pd.api.types.is_numeric_dtype(df[c]) for c in names):raise ValueError('All chosen features must be numeric; encode categorical predictors explicitly')
        X=df[names].to_numpy(dtype=float)
        identities=np.array([hashlib.sha256(np.nan_to_num(r,nan=9.123456e287,posinf=9.123456e287,neginf=9.123456e287).astype('<f8').tobytes()).hexdigest() for r in X])
        if group_col:
            if df[group_col].isna().any():raise ValueError('Group IDs cannot be missing')
            g=union_groups(identities,df[group_col].astype(str).to_numpy())
        else:g=identities
    if len(names)>128:raise ValueError('CPU web limit: 128 numeric features')
    present=~df[target].isna()
    if task=='regression':
        yy=pd.to_numeric(df[target],errors='coerce').to_numpy(float)
        if np.any(present & ~np.isfinite(yy)):raise ValueError('Regression targets must be numeric and finite; leave unknown targets blank')
    else:yy=df[target].fillna('').astype(str).to_numpy()
    labeled=np.flatnonzero(present);unlabeled=np.flatnonzero(~present)
    if len(labeled)<30 or len(np.unique(g[labeled]))<8:raise ValueError('Need at least 30 labeled rows and 8 independent entity groups')
    xl,yl,gl=X[labeled],yy[labeled],g[labeled]
    if task=='classification':
        if any(len(np.unique(gl[yl==c]))<5 for c in np.unique(yl)):raise ValueError('Each class needs at least 5 independent groups for outer and inner splitting')
        tr,te=next(StratifiedGroupKFold(5,shuffle=True,random_state=seed).split(xl,yl,gl))
        if set(yl[tr])!=set(yl) or set(yl[te])!=set(yl):raise ValueError('A held-out partition lacks a class; add groups or revise the grouping')
    else:tr,te=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed).split(xl,yl,gl))
    assert not set(gl[tr]) & set(gl[te])
    scale=bool(options.get('standardize',False));remove=bool(options.get('remove_outliers',False))
    prep=NumericPreprocessor(scale).fit(xl[tr]);flags=prep.outliers(X)
    progress(f'Training PARENA {mode}: {len(tr)} training rows; {len(te)} untouched test rows')
    if task=='regression':
        model=PARENARegressor(mode=mode,random_state=seed,standardize=scale,remove_outliers=remove,
            policy=None if options.get('budget')=='full' else quick_policy())
    else:model=PARENAClassifier(mode=mode,random_state=seed,standardize=scale,remove_outliers=remove)
    model.fit(xl[tr],yl[tr],groups=gl[tr],feature_names=names)
    pred=model.predict(xl[te]);prediction=model.predict(X)
    metrics={}
    if task=='regression':
        metrics=dict(MAE=float(mean_absolute_error(yl[te],pred)),RMSE=float(np.sqrt(mean_squared_error(yl[te],pred))),R2=float(r2_score(yl[te],pred)))
    else:
        pp=model.predict_proba(xl[te])
        metrics=dict(accuracy=float(accuracy_score(yl[te],pred)),balanced_accuracy=float(balanced_accuracy_score(yl[te],pred)),macro_F1=float(f1_score(yl[te],pred,average='macro')),log_loss=float(log_loss(yl[te],pp,labels=model.classes_)))
        if len(model.classes_)==2:metrics['ROC_AUC']=float(roc_auc_score(yl[te]==model.classes_[1],pp[:,1]))
    role=np.full(len(df),'unlabeled prediction',dtype=object);role[labeled[tr]]='training (in-sample)';role[labeled[te]]='held-out test'
    output=pd.DataFrame(dict(source_row=np.arange(len(df))+2,role=role,truth=df[target],prediction=prediction,group=g,feature_outlier_flag=flags))
    if task=='classification':
        for c,p in zip(model.classes_,model.predict_proba(X).T):output[f'probability_{c}']=p
    safe_csv(output,folder/'predictions.csv')
    safe_csv(pd.DataFrame(X,columns=names),folder/'features.csv')
    output[['source_row','role','group','feature_outlier_flag']].to_csv(folder/'split_manifest.csv',index=False)
    figures=[]
    progress('Drawing distributions and held-out predictions')
    fig,ax=plt.subplots(figsize=(7,3.7))
    if task=='regression':
        ax.hist(yl[tr],bins='auto',color=COLORS[0],alpha=.7,label='Training');ax.hist(yl[te],bins='auto',color=COLORS[1],alpha=.7,label='Held-out test');ax.set_xlabel('Target value');ax.set_ylabel('Count');ax.legend(frameon=False)
    else:
        classes=np.unique(yl);xx=np.arange(len(classes));ax.bar(xx-.18,[sum(yl[tr]==c) for c in classes],.36,label='Training',color=COLORS[0]);ax.bar(xx+.18,[sum(yl[te]==c) for c in classes],.36,label='Held-out test',color=COLORS[1]);ax.set_xticks(xx,classes,rotation=20);ax.legend(frameon=False);ax.set_ylabel('Count')
    ax.set_title('Target distribution')
    save_figure(fig,'01_target',folder,'Measured targets / class labels, separated by the fixed entity-group split.',figures)
    # Feature distributions: all features exported, paginated for readable plots.
    for page,offset in enumerate(range(0,len(names),12)):
        selected=range(offset,min(offset+12,len(names)));fig,axes=plt.subplots(int(np.ceil(len(selected)/3)),3,figsize=(10,2.35*int(np.ceil(len(selected)/3))),squeeze=False)
        for ax,j in zip(axes.flat,selected):
            v=xl[tr,j];v=v[np.isfinite(v)];ax.hist(v,bins=16,color=COLORS[0],alpha=.8);ax.set_title(names[j][:35],fontsize=9);ax.tick_params(labelsize=8)
        for ax in list(axes.flat)[len(selected):]:ax.axis('off')
        save_figure(fig,f'02_features_{page+1:02}',folder,'Raw training-feature distributions. Missing values are counted in data_quality.json.',figures)
    qprep=NumericPreprocessor().fit(xl[tr]);ztr=qprep.transform(xl[tr]);zall=qprep.transform(X)
    sc=StandardScaler().fit(ztr);pca=PCA(n_components=min(2,len(names)),svd_solver='full').fit(sc.transform(ztr))
    coords=pca.transform(sc.transform(zall));coords=np.pad(coords,((0,0),(0,2-coords.shape[1])))
    fig,ax=plt.subplots(figsize=(6.5,4.5));ax.scatter(*coords[labeled[tr]].T,s=24,c=COLORS[0],alpha=.65,label='Training');ax.scatter(*coords[labeled[te]].T,s=32,c=COLORS[1],label='Held-out test')
    if len(unlabeled):ax.scatter(*coords[unlabeled].T,s=30,c=COLORS[2],marker='x',label='Unlabeled')
    ax.set_title('Dataset representation');ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})');ax.set_ylabel('PC2');ax.legend(frameon=False)
    save_figure(fig,'03_dataset_PCA',folder,'Standardization and PCA fitted on training features only. This is an unsupervised diagnostic, not evidence of predictive accuracy.',figures)
    pd.DataFrame(dict(source_row=np.arange(len(df))+2,PC1=coords[:,0],PC2=coords[:,1],role=role)).to_csv(folder/'PCA_coordinates.csv',index=False)
    progress('Computing CPU SHAP for the training response guide')
    kw=dict(iterations=120,depth=3,thread_count=1,random_seed=seed,verbose=False,allow_writing_files=False)
    guide=(CatBoostRegressor(**kw) if task=='regression' else CatBoostClassifier(**kw)).fit(ztr,yl[tr])
    take=np.random.default_rng(seed).choice(len(tr),min(128,len(tr)),replace=False)
    shap=guide.get_feature_importance(Pool(ztr[take]),type='ShapValues')
    importance=np.mean(abs(shap[...,:-1]),axis=tuple(range(shap.ndim-1)))
    order=np.argsort(importance)[-min(12,len(names)):]
    fig,ax=plt.subplots(figsize=(7,4.7));ax.barh([names[i] for i in order],importance[order],color=COLORS[0]);ax.set_xlabel('Mean |SHAP value|');ax.set_title('Response-guide SHAP')
    save_figure(fig,'04_SHAP',folder,'Exact CatBoost SHAP for a training-only response guide (up to 128 training rows). This explains the guide, not the complete PARENA ensemble; associations are not causal effects.',figures)
    pd.DataFrame(dict(feature=names,mean_absolute_SHAP=importance)).sort_values('mean_absolute_SHAP',ascending=False).to_csv(folder/'SHAP_importance.csv',index=False)
    np.savez_compressed(folder/'SHAP_values.npz',values=shap,training_source_rows=labeled[tr][take]+2)
    # Plot the ACTUAL feature vectors used by the first selected pair model.
    if task=='regression':pair=model.branch_models_['PARENA_core'].models[0]
    else:pair=model.core_.models[0]
    parent=np.array(pair.info['parents']);n_pairs=len(parent)
    sample=np.random.default_rng(seed).choice(n_pairs,min(3000,n_pairs),replace=False);a,b=parent[sample].T
    vectors=pair.representation(pair.x[a],pair.x[b]);ps=StandardScaler().fit(vectors)
    pc=PCA(n_components=min(2,vectors.shape[1]),svd_solver='full').fit_transform(ps.transform(vectors));pc=np.pad(pc,((0,0),(0,2-pc.shape[1])))
    difference=pair.y[a]-pair.y[b]
    fig,ax=plt.subplots(figsize=(6.5,4.5));im=ax.scatter(pc[:,0],pc[:,1],c=difference,cmap='BrBG',s=10,alpha=.65,rasterized=True);fig.colorbar(im,ax=ax,label='Observed response difference');ax.set_title('Augmented pair-feature distribution');ax.set_xlabel('Pair PC1');ax.set_ylabel('Pair PC2')
    save_figure(fig,'05_training_pairs_PCA',folder,f'Actual augmented pair inputs of the first selected core component: {n_pairs:,} ordered pairs; {len(sample):,} shown. Paired observations are dependent. For classification, differences refer to the first class indicator. These are training relationships, not newly measured molecules.',figures)
    pd.DataFrame(dict(pair_index=sample,parent_a=a,parent_b=b,observed_difference=difference,PC1=pc[:,0],PC2=pc[:,1])).to_csv(folder/'pair_projection.csv',index=False)
    pair_sources=labeled[tr][pair.kept_rows] if task=='regression' else labeled[tr][model.core_.keep][pair.kept_rows]
    np.savez_compressed(folder/'all_training_pairs.npz',parents_source_rows=pair_sources[parent]+2,observed_difference=pair.y[parent[:,0]]-pair.y[parent[:,1]])
    fig,ax=plt.subplots(figsize=(6.5,4.5))
    if task=='regression':
        ax.scatter(yl[te],pred,color=COLORS[0],s=35,alpha=.8);lo=min(min(yl[te]),min(pred));hi=max(max(yl[te]),max(pred));ax.plot([lo,hi],[lo,hi],color='#9ca6a2',ls='--');ax.set_xlabel('Measured');ax.set_ylabel('Predicted');ax.set_title(f'Held-out regression | MAE {metrics["MAE"]:.4g}')
    else:
        cm=confusion_matrix(yl[te],pred,labels=model.classes_);ax.imshow(cm,cmap='Greens');ax.set_xticks(range(len(model.classes_)),model.classes_,rotation=30);ax.set_yticks(range(len(model.classes_)),model.classes_);ax.set_xlabel('Predicted class');ax.set_ylabel('Observed class');ax.set_title(f'Held-out classification | balanced accuracy {metrics["balanced_accuracy"]:.3f}')
        for i in range(len(cm)):
            for j in range(len(cm)):ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>cm.max()*.6 else '#183b33')
    save_figure(fig,'06_predictions',folder,'Performance on all fixed held-out test rows. No test-row outlier deletion. One split is exploratory, not a claim of statistically significant superiority.',figures)
    quality=dict(missing_features=int((~np.isfinite(X)).sum()),missing_by_feature=dict(zip(names,(~np.isfinite(X)).sum(0).astype(int).tolist())),
        all_missing_training_columns=[names[i] for i in prep.empty_columns_],outlier_rule='Feature-only 3 IQR fences learned on training rows; columns with <=5 values or zero IQR exempt',
        flagged_training_rows=int(flags[labeled[tr]].sum()),flagged_test_rows=int(flags[labeled[te]].sum()),remove_training_outliers=remove,
        training_rows_after_rule=int(len(tr)-flags[labeled[tr]].sum()) if remove else len(tr),test_rows_retained=len(te),
        training_medians=prep.medians_.tolist(),input_standardization=scale)
    code_files=sorted((ROOT/'package/src/parena').glob('*.py'))+[ROOT/'package/src/parena/frozen_policy.json',Path(__file__)]
    code_hash=hashlib.sha256(b''.join(p.read_bytes() for p in code_files)).hexdigest()
    summary=dict(version='0.4.1',code_sha256=code_hash,task=task,mode=mode,target=target,features=names,rows=len(df),labeled_rows=len(labeled),unlabeled_rows=len(unlabeled),train_rows=len(tr),test_rows=len(te),
        train_groups=len(set(gl[tr])),test_groups=len(set(gl[te])),seed=seed,metrics=metrics,quality=quality,pair_count=n_pairs,figures=figures,
        options=options,diagnostics=model.diagnostics_,seconds=time.perf_counter()-start,
        validation='One fixed group-disjoint outer holdout (approximately 20%); three-fold training-side model selection. Test labels are used only for evaluation.',
        runtime=dict(python=sys.version.split()[0],platform=platform.system(),numpy=np.__version__,pandas=pd.__version__,device='CPU',threads=1),
        caveats=['Classification is a new extension; broad comparative validation is pending.', 'PCA overlap alone does not establish augmentation quality.', 'SHAP plot describes a response guide, not the complete PARENA ensemble.', 'Model remains fitted to the stated training partition; predictions on training rows are in-sample.'])
    for name,obj in [('summary.json',summary),('data_quality.json',quality),('model_selection.json',model.diagnostics_)]:
        (folder/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v)),encoding='utf8')
    progress('Writing downloadable PDF and reproducibility bundle')
    make_report(summary,folder)
    with zipfile.ZipFile(folder/'results.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in folder.iterdir():
            if p.is_file() and p.name not in ['results.zip','input.csv']:z.write(p,p.name)
    return summary


def union_groups(a,b):
    """合并重复特征/分子身份与用户分组的连通关系，防止同实体跨训练测试。"""
    parent=list(range(len(a)))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for vals in [a,b]:
        first={}
        for i,v in enumerate(vals):
            if v in first:parent[find(i)]=find(first[v])
            else:first[v]=i
    return np.array([str(find(i)) for i in range(len(a))])


def safe_csv(df,path):
    """导出表格时转义潜在公式文本，避免电子表格把用户文本作为公式执行。"""
    safe=df.copy()
    for c in safe.select_dtypes(include=['object','string']).columns:
        safe[c]=safe[c].map(lambda x:"'"+x if isinstance(x,str) and x.startswith(('=','+','-','@','\t','\r')) else x)
    safe.to_csv(path,index=False,encoding='utf-8-sig')


def make_report(s,folder):
    """生成包含流程、指标、全部诊断图与解释限制的本地 PDF。"""
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,PageBreak,Table,TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from xml.sax.saxutils import escape
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    styles=getSampleStyleSheet()
    for v in styles.byName.values():
        v.fontName='Helvetica'
        if hasattr(v,'fontSize'):v.leading=max(v.fontSize*1.45,14)
    body=[]
    def para(t,style='BodyText'):
        text=escape(str(t))
        if any(ord(c)>127 for c in str(t)):text='<font name="STSong-Light">'+text+'</font>'
        body.extend([Paragraph(text,styles[style]),Spacer(1,9)])
    para('PARENA 0.4.1 | Analysis report','Title')
    para(f'{s["task"].title()} · {s["mode"]} · CPU · seed {s["seed"]}','Heading2')
    para(f'Target: {s["target"]}. {s["rows"]} rows; {len(s["features"])} features; {s["train_rows"]} training rows and {s["test_rows"]} held-out test rows.')
    para(s['validation'])
    for k,v in s['metrics'].items():para(f'{k}: {v:.6g}')
    para('Data treatment','Heading2')
    q=s['quality']
    para(f'Missing / nonfinite feature values: {q["missing_features"]}. Filled with training-fold medians. Empty training columns: {len(q["all_missing_training_columns"])}.')
    para(f'Feature outliers flagged: {q["flagged_training_rows"]} training rows and {q["flagged_test_rows"]} test rows. Training-only removal: {q["remove_training_outliers"]}. Training rows after the rule: {q["training_rows_after_rule"]}; all {q["test_rows_retained"]} test rows retained.')
    para('Rule: 3 IQR fences from training features; discrete and zero-IQR columns exempt. Full column-level audit: data_quality.json.')
    para('How predictions are obtained','Heading2')
    para('Regression: training-fold relevance weights define neighborhoods; learned response differences are combined with observed anchor responses. Classification: learn one-versus-rest class-indicator differences, reconstruct and normalize class scores, then select temperature within training folds. Auto may combine core and baseline predictions using training-only validation.')
    para('Interpretation','Heading2')
    for t in s['caveats']:para(t)
    for f in s['figures']:
        body.append(PageBreak());para(f['name'].replace('_',' '),'Heading2')
        from PIL import Image as PI
        p=folder/(f['name']+'.png');w,h=PI.open(p).size;ratio=min(470/w,580/h)
        body.append(Image(str(p),width=w*ratio,height=h*ratio));body.append(Spacer(1,10));para(f['caption'])
    SimpleDocTemplate(str(folder/'PARENA_report.pdf'),pagesize=(595,842),leftMargin=48,rightMargin=48,topMargin=42,bottomMargin=42).build(body)

"""PARENA 本机服务：仅监听 127.0.0.1；会话令牌验证；任务串行、CPU 计算。

启动：python web/server.py。公开网页只调用这个本机服务，研究数据不上传 GitHub。
"""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse,parse_qs
import os,sys,secrets,json,base64,threading,traceback,mimetypes,hashlib,time

os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('MKL_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from analysis import read_table,inspect_table,run_analysis

TOKEN=secrets.token_urlsafe(32)
PORT=int(os.environ.get('PARENA_PORT','8765'))
PUBLIC='https://generationzprogrammer.github.io/climate-agent-news/parena/'
ALLOWED={'https://generationzprogrammer.github.io',f'http://127.0.0.1:{PORT}',f'http://localhost:{PORT}'}
JOBS={};LOCK=threading.Lock();POOL=ThreadPoolExecutor(max_workers=1)
OUT=HERE.parent/'local_results';OUT.mkdir(exist_ok=True)


def work(job,df,options,source_hash):
    """把一个上传表的分析保存到独立目录，状态中不放原始记录。"""
    def status(message):
        with LOCK:JOBS[job]['message']=message
    try:
        folder=OUT/job
        folder.mkdir(parents=True,exist_ok=True)
        (folder/'input_sha256.txt').write_text(source_hash,encoding='ascii')
        result=run_analysis(df,options,folder,status)
        with LOCK:JOBS[job].update(state='complete',message='Analysis complete',result=result)
    except Exception as e:
        folder=OUT/job;folder.mkdir(exist_ok=True)
        (folder/'error.log').write_text(traceback.format_exc(),encoding='utf8')
        with LOCK:JOBS[job].update(state='error',message=str(e))


class Handler(BaseHTTPRequestHandler):
    """提供本机静态预览和鉴权后的文件分析接口。"""
    server_version='PARENA/0.4.1'
    def log_message(self,format,*args):
        # 路径、令牌和数据不写进访问日志。
        pass

    def send(self,code,body,ctype='application/json; charset=utf-8'):
        if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False).encode('utf8')
        self.send_response(code);self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        origin=self.headers.get('Origin')
        if origin in ALLOWED:
            self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
        self.end_headers();self.wfile.write(body)

    def authorized(self):
        host=self.headers.get('Host','').split(':')[0]
        origin=self.headers.get('Origin')
        if host not in ['127.0.0.1','localhost'] or (origin and origin not in ALLOWED):
            self.send(403,{'error':'Unrecognized host/origin'});return False
        if not secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN):
            self.send(401,{'error':'Connect with the session key printed by the local launcher'});return False
        return True

    def do_OPTIONS(self):
        if self.headers.get('Origin') not in ALLOWED:self.send(403,{'error':'Origin blocked'});return
        self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers['Origin'])
        self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS');self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type')
        self.send_header('Access-Control-Allow-Private-Network','true');self.send_header('Vary','Origin');self.end_headers()

    def do_GET(self):
        path=urlparse(self.path).path
        if path.startswith('/api/'):
            if not self.authorized():return
            if path=='/api/health':self.send(200,dict(version='0.4.1',device='CPU',data_location='This computer'));return
            parts=path.split('/')
            if len(parts)>=4 and parts[2]=='jobs' and parts[3] in JOBS:
                job=parts[3]
                if len(parts)==4:
                    with LOCK:data=dict(JOBS[job])
                    self.send(200,data);return
                if len(parts)==5:
                    p=(OUT/job/parts[4]).resolve()
                    if p.parent==(OUT/job).resolve() and p.is_file() and p.name!='error.log':
                        self.send(200,p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream');return
            self.send(404,dict(error='Result not found'));return
        p=(HERE/'public'/('index.html' if path=='/' else path.lstrip('/'))).resolve()
        if p.is_relative_to((HERE/'public').resolve()) and p.is_file():self.send(200,p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
        else:self.send(404,dict(error='Not found'))

    def do_POST(self):
        if not self.authorized():return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<1 or length>17*1024*1024:raise ValueError('Request exceeds 17 MB')
            if not self.headers.get('Content-Type','').startswith('application/json'):raise ValueError('Use JSON request encoding')
            body=json.loads(self.rfile.read(length));data=base64.b64decode(body['data'],validate=True)
            df=read_table(data,body['filename'])
            if self.path=='/api/inspect':self.send(200,inspect_table(df));return
            if self.path!='/api/jobs':self.send(404,dict(error='Unknown endpoint'));return
            with LOCK:
                if any(j['state']=='running' for j in JOBS.values()):self.send(409,dict(error='One CPU task is already running; wait for completion'));return
                job=time.strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(4)
                JOBS[job]=dict(id=job,state='running',message='Preparing data')
            POOL.submit(work,job,df,body.get('options',{}),hashlib.sha256(data).hexdigest())
            self.send(202,dict(id=job,state='running'))
        except Exception as e:self.send(400,dict(error=str(e)))


if __name__=='__main__':
    # 会话令牌只打印在本机终端，不写入文件；网页 fragment 不发送给 GitHub。
    print('PARENA 0.4.1 | local CPU service',flush=True)
    print('Open local workspace: '+f'http://127.0.0.1:{PORT}/#token={TOKEN}',flush=True)
    print('Open published workspace: '+PUBLIC+f'#token={TOKEN}',flush=True)
    print('Session key: '+TOKEN,flush=True)
    print('Close this terminal or press Ctrl+C to stop. Data remain in local_results.',flush=True)
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()

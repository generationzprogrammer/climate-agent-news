"""生成公开可分享的模拟回归数据，用于检查安装和复现流程。"""
import argparse
from pathlib import Path
import numpy as np


def make_data(path, seed=731):
    """用途：保存带实体分组的数值回归示例。
    输入：path 为输出 NPZ，seed 固定随机过程。
    输出：写入 60 行、6 个特征、30 个分组；标签由明确的模拟公式生成。
    """
    rng = np.random.default_rng(seed)
    x = rng.normal(size=(60, 6))
    y = 2*x[:, 0]+.4*x[:, 1]**2-x[:, 2]+rng.normal(0, .05, len(x))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, x=x, y=y, groups=np.repeat(np.arange(30), 2).astype(str),
                        feature_names=np.array([f'x{i}' for i in range(6)]),
                        ids=np.array([f'demo_{i}' for i in range(len(x))]))
    print(f'Synthetic demonstration data saved: {path}')


def main():
    """用途：从命令行生成示例数据。
    输入：--output 指定路径；默认 data/demo.npz，相对于当前工作目录。
    输出：保存模拟数据文件。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('data/demo.npz'))
    args = parser.parse_args()
    make_data(args.output)


if __name__ == '__main__':
    main()

"""演示用 SMILES 和模拟标签训练 KPI64 分子预测接口。"""
from parena import PARENARegressor
from parena.chemistry import kpi64


def main():
    """用途：验证无需外部目录即可执行分子特征化、分组及预测。
    输入：函数内定义的示例分子；标签取已知描述符的组合，仅供程序演示。
    输出：打印两个查询分子的模型预测，不用于报告科研效果。
    """
    smiles = ['CCO', 'CCCO', 'CCCCO', 'CC(C)O', 'CC(C)(C)O', 'COC',
              'CCOC', 'CCOCC', 'CC(=O)O', 'CCC(=O)O', 'CC(=O)OC', 'CC(=O)OCC',
              'CCN', 'CCCN', 'CC(C)N', 'CC#N', 'CCC#N', 'CCCC#N']
    y = [float(kpi64(s)[0]) for s in smiles]  # 用分子量作模拟标签，方便检查调用流程。
    model = PARENARegressor(random_state=728).fit_smiles(smiles, y)
    print(model.predict_smiles(['CCCCCO', 'CCCOCC']))


if __name__ == '__main__':
    main()

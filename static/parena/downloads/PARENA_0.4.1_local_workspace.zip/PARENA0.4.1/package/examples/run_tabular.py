"""演示从数值 NPZ 到训练、预测、保存模型的完整过程。"""
import argparse
from pathlib import Path
import joblib
import numpy as np
from parena import PARENARegressor
from parena.estimators import folds
from parena.study import load_dataset


def main():
    """用途：在一个固定分组留出集上演示完整默认策略。
    输入：--data 为 NPZ 路径，--output 为输出目录。
    输出：模型、训练诊断、各分支预测及留出集 MAE。
    示例标签是模拟值，运行结果仅用于验证程序。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=Path('data/demo.npz'))
    parser.add_argument('--output', type=Path, default=Path('outputs/demo'))
    args = parser.parse_args()
    data = load_dataset(args.data)
    tr, te = folds(data['groups'], seed=1729)[0]
    model = PARENARegressor(random_state=728)
    model.fit(data['x'][tr], data['y'][tr], groups=data['groups'][tr],
              feature_names=data['feature_names'].tolist())
    args.output.mkdir(parents=True, exist_ok=True)
    model.export_diagnostics(args.output/'training_decisions.json')
    joblib.dump(model, args.output/'model.joblib')
    predictions = {'PARENA_auto': model.predict(data['x'][te])}
    for branch in model.diagnostics_['branch_names']:
        predictions[branch] = model.predict_branch(data['x'][te], branch)
    np.savez_compressed(args.output/'predictions.npz', truth=data['y'][te],
                        train_indices=tr, test_indices=te, **predictions)
    for name, p in predictions.items():
        print(f'{name}: held-out MAE = {np.mean(abs(p-data["y"][te])):.6f}')


if __name__ == '__main__':
    main()

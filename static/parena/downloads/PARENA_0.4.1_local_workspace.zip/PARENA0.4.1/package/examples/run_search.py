"""最小候选搜索示例：用模拟数值评价展示预算分配接口。

输入为两个生成函数，输出为每个操作的实际尝试次数和候选数。
模拟 hit 只服务于软件测试，不代表任何分子性质的验证。
"""
from parena import PARENASearch


def broad(rng, archive):
    """用途：在整个数值区间均匀提议；返回含 candidate 的字典。"""
    return {'candidate':int(rng.integers(0,100000))}


def local(rng, archive):
    """用途：在较优数值区间提议；rng 保证可复现，archive 为已有候选。"""
    return {'candidate':int(rng.integers(0,10000))}


def identify(candidate):
    """用途：为候选提供唯一字符串身份；返回 None 可表示不合格。"""
    return str(candidate)


def evaluate(candidates):
    """用途：返回身份、模拟命中状态和排序分数；分数越小越优。"""
    return [dict(identity=str(x),predicted_hit=int(x)<5000,rank_score=float(x)) for x in candidates]


if __name__=='__main__':
    result=PARENASearch(max_attempts=1000,batch_size=50,random_state=728).run(
        {'broad':broad,'local':local},identify,evaluate)
    print('Status:',result['status'])
    print('Actual attempts:',result['arm_attempts'])
    print('Unique candidates:',len(result['archive']))

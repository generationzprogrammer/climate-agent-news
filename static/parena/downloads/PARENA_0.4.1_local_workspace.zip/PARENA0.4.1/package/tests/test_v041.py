"""检查 0.4.1 的训练内预处理、缺失值和分类概率。"""
import unittest
import numpy as np
from parena import PARENARegressor,PARENAClassifier
from parena.preprocessing import NumericPreprocessor
from parena.estimators import Context
from parena.study import cv_config
from tempfile import TemporaryDirectory
from pathlib import Path

CFG=dict(family='pair_transport',geometry='importance',representation='diff',guide=False,
         model=dict(kind='et',trees=12,leaf=2),q=.8,radius=.5,pairs_per_point=5,max_anchors=10)
POL=dict(version='test',pool=[CFG],baseline_pools={x:[] for x in ['Original','Mixup','CMixup']})

class Test041(unittest.TestCase):
    def test_missing_and_train_only_statistics(self):
        p=NumericPreprocessor().fit([[1,np.nan],[3,np.nan]])
        np.testing.assert_allclose(p.transform([[np.nan,100]]),[[2,100]])
        self.assertEqual(p.empty_columns_,[1])
        # Validation-only extremes cannot modify an already fitted imputer.
        p.transform([[1e9,np.nan]])
        np.testing.assert_allclose(p.medians_,[2,0])

    def test_cv_uses_raw_fold_input(self):
        rng=np.random.default_rng(1);x=rng.normal(size=(36,3));x[::3,0]=np.nan
        y=2*x[:,1]+rng.normal(size=36)*.1
        ctx=Context(x,y,seed=2)
        with TemporaryDirectory() as td:
            r=cv_config(ctx,CFG,Path(td)/'cv.json')
        self.assertTrue(np.isfinite(r['oof']).all())
        # Inspect fold processors: each median must equal its own raw training subset.
        fs,cs=ctx.cache[('cv3',ctx.seed)]
        for (a,b),c in zip(fs,cs):
            np.testing.assert_allclose(c.preprocessor.medians_,np.nanmedian(x[a],axis=0))

    def test_optional_outlier_removal_and_predictions(self):
        rng=np.random.default_rng(4);x=rng.normal(size=(48,3));y=x[:,0]+x[:,1];x[-1,0]=1e6;x[2,0]=np.nan
        m=PARENARegressor(mode='core',policy=POL,remove_outliers=True).fit(x,y)
        a=m.branch_models_['PARENA_core'].models[0]
        self.assertNotIn(47,a.kept_rows)
        self.assertEqual(len(m.predict(x)),48)
        self.assertTrue(np.isfinite(m.predict(x)).all())

    def test_classification_probabilities_and_group_guard(self):
        rng=np.random.default_rng(2);x=rng.normal(size=(45,4));y=np.where(x[:,0]>0,'high','low');x[::7,1]=np.nan
        m=PARENAClassifier(mode='core',random_state=2).fit(x,y)
        p=m.predict_proba(x[:6]);np.testing.assert_allclose(p.sum(1),1)
        self.assertTrue((p>=0).all());self.assertTrue(set(m.predict(x)) <= {'high','low'})
        with self.assertRaises(ValueError):PARENAClassifier().fit(x,y,groups=y)

if __name__=='__main__':unittest.main()

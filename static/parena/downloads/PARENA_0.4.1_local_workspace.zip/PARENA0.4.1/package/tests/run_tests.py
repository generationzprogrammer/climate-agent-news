"""可独立执行的验证：接口、分组隔离、缓存、KPI64 和完整数值回归。

普通模式执行快速功能测试；--full 额外运行完整冻结候选池的数值回归。
所有数据均为模拟值或公开结构示例，不包含研究数据库。
"""
import ast
import json
import os
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
import unittest

import joblib
import numpy as np
from sklearn.base import clone
import parena
from parena import PARENARegressor
from parena.estimators import Context, folds
from parena.study import cv_config, evaluate_dataset, load_policy
from parena.transport import fit

FULL = '--full' in sys.argv
if FULL:
    sys.argv.remove('--full')
FIXTURE = Path(__file__).resolve().parent/'fixtures/numerical_reference.npz'


def small_policy():
    """用途：定义用于接口测试的四分支小配置。
    输入：无参数。
    输出：每分支一个配置的策略；完整数值回归仍使用包内完整候选池。
    """
    return dict(version='test-only', pool=[dict(family='pair_transport', geometry='importance',
                model=dict(kind='et', trees=12, leaf=2), q=.9, radius=1.)],
                baseline_pools={name: [dict(family=name, model=dict(kind='et', trees=12, leaf=2))]
                                for name in ['Original', 'Mixup', 'CMixup']})


class TestPortablePackage(unittest.TestCase):
    """用途：检查无需研究目录即可工作的公共接口和数据隔离约束。
    输入：包内模拟数值参考文件。
    输出：标准 unittest 通过或失败记录。
    """

    @classmethod
    def setUpClass(cls):
        """用途：一次载入固定模拟输入并拟合快速测试模型。
        输入：无外部数据。
        输出：类属性 ref 和 model，供各项测试共享。
        """
        with np.load(FIXTURE, allow_pickle=False) as a:
            cls.ref = {k: a[k] for k in a.files}
        cls.model = PARENARegressor(policy=small_policy()).fit(
            cls.ref['x'], cls.ref['y'], groups=cls.ref['groups'])

    def test_public_api_and_serialization(self):
        """用途：核对预测、克隆和模型保存/加载接口。
        输入：已拟合测试模型和模拟查询。
        输出：断言加载前后的预测完全一致。
        """
        p = self.model.predict(self.ref['query'])
        self.assertTrue(np.isfinite(p).all())
        self.assertEqual(clone(PARENARegressor()).random_state, 728)
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'model.joblib'
            joblib.dump(self.model, path)
            np.testing.assert_array_equal(joblib.load(path).predict(self.ref['query']), p)
        np.testing.assert_array_equal(self.model.rank_candidates(self.ref['query']), np.argsort(p, kind='stable'))

    def test_group_split_and_pair_lineage(self):
        """用途：核验实体隔离和训练样本对来源。
        输入：带重复实体标记的模拟数据。
        输出：断言各折实体不重叠、父样本索引均在训练数据内。
        """
        for tr, va in folds(self.ref['groups']):
            self.assertFalse(set(self.ref['groups'][tr]) & set(self.ref['groups'][va]))
        model = self.model.branch_models_['PARENA_core'].models[0]
        parents = np.array(model.info['parents'])
        self.assertTrue((parents >= 0).all() and (parents < len(self.ref['y'])).all())
        self.assertTrue((parents[:, 0] != parents[:, 1]).all())

    def test_input_errors_and_empty_queries(self):
        """用途：检查错列、非有限数值和空查询的处理。
        输入：有意构造的错误特征表和空数组。
        输出：错误输入抛出异常；空查询返回空预测。
        """
        with self.assertRaises(ValueError):
            self.model.predict(np.ones((2, 5)))
        self.assertTrue(np.isfinite(self.model.predict(np.full((2, 6), np.nan))).all())
        self.assertEqual(self.model.predict(np.empty((0, 6))).shape, (0,))
        with self.assertRaises(ValueError):
            self.model.predict_branch(self.ref['query'], 'unknown')

    def test_cache_rejects_changed_data(self):
        """用途：确认缓存不会跨不同训练标签误用。
        输入：同一配置及两个标签不同的训练上下文。
        输出：相同输入可复用；更改输入必须触发缓存不匹配异常。
        """
        cfg = small_policy()['baseline_pools']['Original'][0]
        ctx = Context(self.ref['x'], self.ref['y'], self.ref['groups'])
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'candidate.json'
            a = cv_config(ctx, cfg, path)
            self.assertEqual(a, cv_config(ctx, cfg, path))
            changed = Context(self.ref['x'], self.ref['y']+1, self.ref['groups'])
            with self.assertRaises(ValueError):
                cv_config(changed, cfg, path)

    def test_kpi64_values_and_identity(self):
        """用途：核对 64 列顺序、描述符数值、分支点和分子身份。
        输入：24 个代表性结构及其固定参考值。
        输出：数值一致，并确认返回数组不会污染缓存。
        """
        from parena.chemistry import kpi64, FEATURE_NAMES, identity
        self.assertEqual(FEATURE_NAMES, self.ref['feature_names'].tolist())
        actual = np.array([kpi64(s) for s in self.ref['smiles']])
        np.testing.assert_allclose(actual, self.ref['descriptors'], rtol=1e-9, atol=1e-10)
        self.assertEqual(len(FEATURE_NAMES), 64)
        self.assertEqual(kpi64('CC(C)O')[FEATURE_NAMES.index('#Bran')], 1)
        self.assertEqual(identity('CCO'), identity('OCC'))
        before = kpi64('CCO')
        changed = kpi64('CCO')
        changed[:] = -999
        np.testing.assert_array_equal(kpi64('CCO'), before)
        with self.assertRaises(ValueError):
            kpi64('')

    def test_smiles_training(self):
        """用途：实际执行分子训练和预测，检查包内特征化依赖完整。
        输入：代表性分子及由描述符构造的模拟标签。
        输出：模型有 64 个输入，预测有限且可按分子身份分组。
        """
        from parena.chemistry import FEATURE_NAMES
        molecules = self.ref['smiles'][:16].tolist()
        model = PARENARegressor(policy=small_policy()).fit_smiles(iter(molecules), self.ref['descriptors'][:16, 0])
        self.assertEqual(model.n_features_in_, 64)
        self.assertEqual(model.feature_names_in_, FEATURE_NAMES)
        self.assertTrue(np.isfinite(model.predict_smiles(['CCCO'])).all())
        self.assertEqual(model.predict_smiles([]).shape, (0,))

    def test_export_training(self):
        """用途：核对导出样本对的实测差值和归一化训练标签。
        输入：拟合后的测试模型。
        输出：导出数组与父样本关系一致。
        """
        with TemporaryDirectory() as tmp:
            self.model.export_augmented_training(tmp)
            with np.load(Path(tmp)/'component_0_pairs.npz', allow_pickle=False) as a:
                i, j = a['parents'].T
                np.testing.assert_array_equal(a['observed_difference'], a['real_y'][i]-a['real_y'][j])
                np.testing.assert_allclose(a['normalized_training_target']*a['target_scale'], a['training_response_difference'])

    def test_outer_evaluation(self):
        """用途：运行完整外层分组评估入口并核对输出。
        输入：固定模拟表和快速功能测试策略。
        输出：三个测试折覆盖全部输入，计算可复核的 MAE。
        """
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'data.npz'
            np.savez_compressed(path, x=self.ref['x'], y=self.ref['y'], groups=self.ref['groups'])
            out = Path(tmp)/'evaluation'
            result = evaluate_dataset(path, out, policy=small_policy())
            self.assertEqual(sum(r['test_rows'] for r in result['folds']), len(self.ref['y']))
            for f in range(3):
                self.assertTrue((out/f'fold_{f}/decision_before_test.json').exists())
            self.assertTrue(all(np.isfinite(v) for v in result['pooled_mae'].values()))

    def test_source_and_docstrings(self):
        """用途：检查独立模块、统一命名和中文阅读注释的完整性。
        输入：实际安装位置的 Python 源文件。
        输出：禁止研究阶段目录、私有路径及缺失的函数/类说明。
        """
        root = Path(parena.__file__).parent
        for path in root.glob('*.py'):
            text = path.read_text('utf8')
            self.assertIsNone(re.search(r'phase\d|charm|kpi63|sys\.path|C:[/\\]Users', text, re.I), path.name)
            tree = ast.parse(text)
            self.assertTrue(ast.get_docstring(tree), path.name)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                    self.assertTrue(ast.get_docstring(node), f'{path.name}:{node.name}')

    @unittest.skipUnless(FULL, 'Use --full to run all frozen candidates and full auto regression')
    def test_full_numerical_regression(self):
        """用途：验证完整 12 个核心候选和 106 配置 auto 搜索的数值兼容性。
        输入：固定随机种子、模拟训练表和发布前记录的数值参考。
        输出：各候选、各分支及 auto 预测在浮点容差内与参考一致。
        """
        ctx = Context(self.ref['x'], self.ref['y'], self.ref['groups'], 728)
        legacy=json.loads((FIXTURE.parent/'legacy_policy.json').read_text('utf8'))
        for j, cfg in enumerate(legacy['pool']):
            p = fit(ctx, cfg).predict(self.ref['query'])
            np.testing.assert_allclose(p, self.ref[f'candidate_{j}'], rtol=1e-7, atol=1e-8)
        model = PARENARegressor(policy=legacy).fit(self.ref['x'], self.ref['y'], groups=self.ref['groups'])
        np.testing.assert_allclose(model.predict(self.ref['query']), self.ref['auto'], rtol=1e-7, atol=1e-8)
        for branch in model.diagnostics_['branch_names']:
            np.testing.assert_allclose(model.predict_branch(self.ref['query'], branch), self.ref[branch], rtol=1e-7, atol=1e-8)


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""验证 0.4.0 的稀疏组合、独立核心入口、分批预测和真实搜索预算。"""
import unittest
import numpy as np
from parena import PARENARegressor,PARENASearch
from parena.estimators import Context
from parena.transport import PairTransport,convex_weights,Ensemble
from parena.guard import PARENAGuardedRegressor


class TestVersion040(unittest.TestCase):
    """用途：用模拟数据检验新机制的数学约束和数据隔离接口。"""

    def test_mae_linear_ensemble(self):
        """用途：验证组合权重非负且归一，完全错误成员不会被强制混入。"""
        y=np.arange(20,dtype=float);pred=np.c_[y,y+10,y-5]
        w=convex_weights(pred,y,prior='best')
        self.assertAlmostEqual(w.sum(),1.);self.assertTrue((w>=0).all())
        np.testing.assert_allclose(pred@w,y,atol=1e-9)
        self.assertAlmostEqual(w[0],1.)

    def test_optional_extrapolation_fallback(self):
        """用途：验证范围只由训练标签确定，正常预测不变，极端预测会回退。"""
        rng=np.random.default_rng(17);x=rng.normal(size=(24,3));y=x[:,0]+.2*x[:,1]
        c=dict(family='pair_transport',geometry='importance',representation='diff',model=dict(kind='et',trees=8,leaf=2),max_anchors=8,pairs_per_point=6)
        policy=dict(version='test',ensemble='complementary',pool=[c],baseline_pools={n:[dict(family=n,model=dict(kind='et',trees=8,leaf=2))] for n in ['Original','Mixup','CMixup']})
        base=PARENARegressor(policy=policy).fit(x,y);model=PARENAGuardedRegressor.from_fitted(base)
        q=x[:3];np.testing.assert_allclose(model.predict(q),base.predict(q))
        span=max(float(np.ptp(y)),6*float(np.std(y)))
        np.testing.assert_allclose(model.response_bounds_,[y.min()-span,y.max()+span])
        class Extreme:
            """用途：制造确定性的异常预测，以检验回退逻辑。"""
            def predict(self,x):
                """用途：每行返回极大值；用于测试，不参与研究预测。"""
                return np.full(len(x),1e9)
        expected=model.fallback_model_.predict(q);model.model_=Extreme()
        np.testing.assert_allclose(model.predict(q),expected)
        self.assertEqual(model.guard_diagnostics_['last_triggered_count'],3)
        self.assertNotIn('extrapolation_guard',base.diagnostics_)

    def test_core_mode_and_bounded_prediction(self):
        """用途：验证 core 可独立训练，大批量与小批量预测一致，训练缓存已释放。"""
        rng=np.random.default_rng(7);x=rng.normal(size=(40,4));y=x[:,0]+x[:,1]**2
        c=dict(family='pair_transport',geometry='response',representation='response_diff',model=dict(kind='et',trees=16,leaf=2),max_anchors=12,pairs_per_point=8,anchor_reliability=True)
        policy=dict(version='test',ensemble='complementary',pool=[c],baseline_pools={n:[dict(family=n,model=dict(kind='et',trees=8,leaf=2))] for n in ['Original','Mixup','CMixup']})
        m=PARENARegressor(mode='core',policy=policy).fit(x,y)
        self.assertEqual(m.diagnostics_['branch_names'],['PARENA_core'])
        self.assertEqual(m._training_context.cache,{})
        q=rng.normal(size=(263,4));a=m.predict(q);b=np.concatenate([m.predict(q[i:i+17]) for i in range(0,len(q),17)])
        np.testing.assert_allclose(a,b,rtol=1e-10,atol=1e-10)
        info=m.branch_models_['PARENA_core'].models[0].info
        self.assertLessEqual(info['neighbors']['max'],12)
        self.assertIsNotNone(info['geometry_guide'])

    def test_search_budget_duplicates_and_exhaustion(self):
        """用途：重复和失败提议计入预算，耗尽操作不补造尝试，运行可复现。"""
        def execute():
            """用途：构造固定的成功、失败和重复提议流，返回完整搜索记录。"""
            items=iter([1,1,None,2,3])
            def propose(rng,archive):
                """用途：每次取出一个真实提议；流耗尽时抛出 StopIteration。"""
                return dict(candidate=next(items))
            def evaluate(values):
                """用途：提供模拟的预测达标结果，用于检查预算统计。"""
                return [dict(identity=v,predicted_hit=v>=2,rank_score=-float(v)) for v in values]
            return PARENASearch(max_attempts=10,batch_size=2).run({'one':propose},lambda x:x,evaluate)
        a,b=execute(),execute();self.assertEqual(a,b)
        self.assertEqual(len(a['raw_attempts']),5);self.assertEqual(len(a['archive']),3)
        self.assertEqual(a['status'],'generators_exhausted')
        self.assertEqual(sum(a['arm_predicted_hits'].values()),2)


if __name__=='__main__':unittest.main(verbosity=2)

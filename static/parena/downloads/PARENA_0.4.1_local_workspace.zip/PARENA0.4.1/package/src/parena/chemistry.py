"""分子规范化、分子身份分组和完整 KPI64 特征计算。

FEATURE_NAMES 明确规定 64 列及其顺序；#Bran 与其他描述符一起直接计算。
所有依赖均来自本包和 RDKit。identity 用于把同一分子的不同写法分到同一组。
"""
import math
from functools import lru_cache
import numpy as np
try:
    from rdkit import Chem
    from rdkit.Chem import AllChem, Descriptors, Fragments, Lipinski, rdFingerprintGenerator
    from rdkit.Chem.MolStandardize import rdMolStandardize
except ImportError as exc:
    raise ImportError('SMILES support requires RDKit. Install with: pip install ".[molecule]"') from exc

FPGEN = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)
TAUTOMERS = rdMolStandardize.TautomerEnumerator()
FEATURE_NAMES = ['Molwt', '#Heavy', '#C', '#O', '#O/#C', '#Het', '#Het/#C', '#R=R', '#R#R', '#Donor', '#Accept', '#Rot', '#Ring', '#Nring', '#AlCR', '#AlHR', '#AlR', '#ArCR', '#ArHR', '#ArR', '#SCR', '#SHR', '#SR', '#Bran', '#OH', '#AlOH', '#ArOH', '#COO', '#AlCOO', '#ArCOO', '#C=O', '#C=O\\COO', '#Ether', '#Ester', '#Halogen', '#Benzene', '#Ar-N', '#ArN', '#ArNH', '#Imine', '#NH2', '#NH1', '#NH0', '#SH', '#Aldehyde', '#Amide', '#Aniline', '#Phenol', '#Epoxide', '#Furan', '#Piperdine', '#Pyridine', '#Lactone', '#Ketone', '#Nitrile', '#Sulfone', 'AvgX', 'AvgI', 'AvgA', 'MaxAPC', 'MinAPC', 'MaxPC', 'MinPC', 'ValE']

def feature_names():
    """用途：提供KPI64 的名称顺序副本。
    输入：无输入。
    输出：返回 64 个描述符名称列表。"""
    return FEATURE_NAMES.copy()

def _count_cl(smiles):
    """用途：按固定描述符定义统计 SMILES 中的氯标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("Cl") + smiles.count("cl")

def _count_si(smiles):
    """用途：按固定描述符定义统计硅标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("Si") + smiles.count("si")

def _count_c(smiles):
    """用途：按固定描述符定义统计碳标记，并排除氯标记的首字母。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    count = smiles.count("C") + smiles.count("c")
    return count - _count_cl(smiles) if "Cl" in smiles or "cl" in smiles else count

def _count_o(smiles):
    """用途：按固定描述符定义统计氧标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("O") + smiles.count("o")

def _count_n(smiles):
    """用途：按固定描述符定义统计氮标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("N") + smiles.count("n")

def _count_f(smiles):
    """用途：按固定描述符定义统计氟标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("F") + smiles.count("f")

def _count_p(smiles):
    """用途：按固定描述符定义统计磷标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("P") + smiles.count("p")

def _count_s(smiles):
    """用途：按固定描述符定义统计硫标记，并处理硅标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    count = smiles.count("S") + smiles.count("s")
    return count - _count_si(smiles) if "Si" in smiles or "si" in smiles else count

def _count_br(smiles):
    """用途：按固定描述符定义统计溴标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    return smiles.count("Br") + smiles.count("br")

def _count_i(smiles):
    """用途：按固定描述符定义统计碘标记，并处理硅标记。
    输入：smiles 为分子字符串。
    输出：返回整数计数。"""
    count = smiles.count("I") + smiles.count("i")
    return count - _count_si(smiles) if "Si" in smiles or "si" in smiles else count

def _explicit_h_smiles(mol):
    """用途：把隐式氢显式加入后转换回 SMILES。
    输入：mol 是 RDKit 分子。
    输出：返回含显式氢的字符串。"""
    return Chem.MolToSmiles(AllChem.AddHs(mol))

def _count_h(mol):
    """用途：按固定描述符定义统计分子的氢数。
    输入：mol 是 RDKit 分子。
    输出：返回整数计数。"""
    smiles = _explicit_h_smiles(mol)
    return smiles.count("H") + smiles.count("h")

def _count_atoms(mol):
    """用途：计算显式氢 SMILES 的字母计数归一化分母。
    输入：mol 是 RDKit 分子。
    输出：返回整数计数。"""
    return sum(character.isalpha() for character in _explicit_h_smiles(mol))

def _weighted_average(smiles, mol, values):
    """用途：按固定元素计数计算一个原子属性的平均值。
    输入：smiles、mol 描述同一分子；values 是按固定元素顺序排列的属性常数。
    输出：返回属性加权平均值。"""
    counts = [
        _count_h(mol),
        _count_c(smiles),
        _count_n(smiles),
        _count_o(smiles),
        _count_f(smiles),
        _count_si(smiles),
        _count_p(smiles),
        _count_s(smiles),
        _count_cl(smiles),
        _count_br(smiles),
        _count_i(smiles),
    ]
    return sum(value * count for value, count in zip(values, counts)) / _count_atoms(mol)

@lru_cache(maxsize=100000)
def _descriptor_values(smiles):
    """用途：按固定顺序一次计算全部 64 个 KPI 描述符。
    输入：smiles 为规范化分子字符串。
    输出：返回不可变数值元组；未定义的电荷描述符按固定约定置零。"""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles}")

    carbon_count = _count_c(smiles)
    oxygen_count = _count_o(smiles)
    hetero_count = Lipinski.NumHeteroatoms(mol)
    rings = mol.GetRingInfo().AtomRings()
    largest_ring = max((len(ring) for ring in rings), default=0)

    avg_x = _weighted_average(
        smiles,
        mol,
        [2.20, 2.55, 3.04, 3.44, 3.98, 1.90, 2.19, 2.58, 3.16, 2.96, 2.66],
    )
    avg_i = _weighted_average(
        smiles,
        mol,
        [
            13.598433,
            11.26030,
            14.5341,
            13.61805,
            17.4228,
            8.15168,
            10.48669,
            10.36001,
            12.96763,
            11.8138,
            10.45126,
        ],
    )
    avg_a = _weighted_average(
        smiles,
        mol,
        [
            0.75420375,
            1.262118,
            -0.07,
            1.4611120,
            3.4011895,
            1.3895220,
            0.7465,
            2.0771029,
            3.612724,
            3.3635880,
            3.059038,
        ],
    )

    raw_features = [
        Descriptors.MolWt(mol),
        Lipinski.HeavyAtomCount(mol),
        carbon_count,
        oxygen_count,
        oxygen_count / (carbon_count + 0.001),
        hetero_count,
        hetero_count / (carbon_count + 0.001),
        smiles.count("="),
        smiles.count("#"),
        Lipinski.NumHDonors(mol),
        Lipinski.NumHAcceptors(mol),
        Lipinski.NumRotatableBonds(mol),
        mol.GetRingInfo().NumRings(),
        largest_ring,
        Lipinski.NumAliphaticCarbocycles(mol),
        Lipinski.NumAliphaticHeterocycles(mol),
        Lipinski.NumAliphaticRings(mol),
        Lipinski.NumAromaticCarbocycles(mol),
        Lipinski.NumAromaticHeterocycles(mol),
        Lipinski.NumAromaticRings(mol),
        Lipinski.NumSaturatedCarbocycles(mol),
        Lipinski.NumSaturatedHeterocycles(mol),
        Lipinski.NumSaturatedRings(mol),
        sum(sum(n.GetAtomicNum() > 1 for n in a.GetNeighbors()) > 2
            for a in mol.GetAtoms() if a.GetAtomicNum() > 1),  # #Bran：重原子分支点数。
        Fragments.fr_Al_OH(mol) + Fragments.fr_Ar_OH(mol),
        Fragments.fr_Al_OH(mol),
        Fragments.fr_Ar_OH(mol),
        Fragments.fr_COO(mol),
        Fragments.fr_Al_COO(mol),
        Fragments.fr_Ar_COO(mol),
        Fragments.fr_C_O(mol),
        Fragments.fr_C_O_noCOO(mol),
        Fragments.fr_ether(mol),
        Fragments.fr_ester(mol),
        Fragments.fr_halogen(mol),
        Fragments.fr_benzene(mol),
        Fragments.fr_Ar_N(mol),
        Fragments.fr_ArN(mol),
        Fragments.fr_Ar_NH(mol),
        Fragments.fr_Imine(mol),
        Fragments.fr_NH2(mol),
        Fragments.fr_NH1(mol),
        Fragments.fr_NH0(mol),
        Fragments.fr_SH(mol),
        Fragments.fr_aldehyde(mol),
        Fragments.fr_amide(mol),
        Fragments.fr_aniline(mol),
        Fragments.fr_phenol(mol),
        Fragments.fr_epoxide(mol),
        Fragments.fr_furan(mol),
        Fragments.fr_piperdine(mol),
        Fragments.fr_pyridine(mol),
        Fragments.fr_lactone(mol),
        Fragments.fr_ketone(mol),
        Fragments.fr_nitrile(mol),
        Fragments.fr_sulfone(mol),
        avg_x,
        avg_i,
        avg_a,
        Descriptors.MaxAbsPartialCharge(mol),
        Descriptors.MinAbsPartialCharge(mol),
        Descriptors.MaxPartialCharge(mol),
        Descriptors.MinPartialCharge(mol),
        Descriptors.NumValenceElectrons(mol),
    ]
    return tuple(0 if math.isnan(value) or math.isinf(value) else value for value in raw_features)

@lru_cache(maxsize=100000)
def canonical(smiles):
    """用途：把有效 SMILES 转成标准的同分异构 SMILES 写法。
    输入：smiles 是单个分子字符串。
    输出：返回规范 SMILES；无效结构报错。"""
    mol=Chem.MolFromSmiles(str(smiles).strip())
    if mol is None or mol.GetNumAtoms() == 0: raise ValueError(f'Invalid SMILES: {smiles!r}')
    return Chem.MolToSmiles(mol,canonical=True,isomericSmiles=True)

@lru_cache(maxsize=100000)
def identity(smiles):
    """用途：给分子生成保守的训练/测试分组身份。
    输入：smiles 是单个分子；会规范互变异构、忽略立体信息。
    输出：返回连接层 InChIKey；不擅自删除盐片段或改变电荷。"""
    mol=TAUTOMERS.Canonicalize(Chem.MolFromSmiles(canonical(smiles)))
    Chem.RemoveStereochemistry(mol)
    key=Chem.MolToInchiKey(mol)
    return key.split('-')[0] if key else Chem.MolToSmiles(mol)

@lru_cache(maxsize=100000)
def fingerprint(smiles):
    """用途：计算 Morgan 指纹，供结构相似性分析。
    输入：smiles 是有效分子字符串。
    输出：返回 RDKit 位向量指纹。"""
    return FPGEN.GetFingerprint(Chem.MolFromSmiles(canonical(smiles)))
def kpi64(smiles):
    """用途：把一个 SMILES 转为完整 KPI64 数值向量。
    输入：smiles 是可被 RDKit 解析的非空分子字符串。
    输出：返回长度 64 的数组，列顺序为 FEATURE_NAMES；返回副本保护缓存。
    #Bran 统计连接超过两个重原子的重原子数。
    """
    result = np.array(_descriptor_values(canonical(smiles)), dtype=float)
    if result.shape != (64,) or not np.isfinite(result).all():
        raise ValueError('KPI64 schema failure')
    return result

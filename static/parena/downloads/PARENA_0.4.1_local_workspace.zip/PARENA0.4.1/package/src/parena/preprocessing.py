"""训练折内的数据处理：填补缺失值、可选标准化，以及可追溯的异常值筛查。"""
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin


class NumericPreprocessor(TransformerMixin, BaseEstimator):
    """数值特征处理器。fit 仅接收训练数据；transform 保持列数和列顺序。"""
    def __init__(self, standardize=False):
        """保存是否对模型输入做均值/标准差变换。"""
        self.standardize = standardize

    def fit(self, X, y=None):
        """按列学习中位数、均值和标准差；训练内全缺失列填 0 并记录。"""
        x = np.asarray(X, float)
        if x.ndim != 2 or not len(x):
            raise ValueError('Expected a nonempty numeric table')
        self.n_features_in_ = x.shape[1]
        self.empty_columns_ = np.flatnonzero(~np.isfinite(x).any(axis=0)).tolist()
        self.medians_ = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in x.T])
        v = np.where(np.isfinite(x), x, self.medians_)
        self.means_ = v.mean(0)
        self.scales_ = v.std(0)
        self.scales_[self.scales_ < 1e-12] = 1.
        q1, q3 = np.quantile(v, [.25, .75], axis=0)
        iqr = q3-q1
        # 二值列及 IQR=0 的稀疏计数列不据此判异常，以免删除稀有化学基团。
        active = (iqr > 1e-12) & np.array([len(np.unique(c)) > 5 for c in v.T])
        self.lower_ = np.where(active, q1-3*iqr, -np.inf)
        self.upper_ = np.where(active, q3+3*iqr, np.inf)
        return self

    def transform(self, X):
        """用已保存的训练统计量转换新数据；非有限特征按缺失处理。"""
        x = np.asarray(X, float)
        if x.ndim != 2 or x.shape[1] != self.n_features_in_:
            raise ValueError('Feature schema mismatch')
        v = np.where(np.isfinite(x), x, self.medians_)
        return (v-self.means_)/self.scales_ if self.standardize else v

    def outliers(self, X):
        """返回每行是否至少一列越过训练内 3 IQR 围栏；缺失值不算异常。"""
        x = np.asarray(X, float)
        return np.any(np.isfinite(x) & ((x < self.lower_) | (x > self.upper_)), axis=1)


class PreparedModel:
    """保存模型及其训练折处理器，确保新数据使用同一变换。"""
    def __init__(self, model, preprocessor, kept_rows=None):
        """保存已拟合模型、训练内处理器和保留行索引。"""
        self.model = model
        self.preprocessor = preprocessor
        self.kept_rows = kept_rows

    def predict(self, X):
        """输入原始特征，输出模型预测。"""
        return self.model.predict(self.preprocessor.transform(X))

    def __getattr__(self, name):
        """允许读取底层模型诊断，同时保护反序列化初始化过程。"""
        if name.startswith('__') or 'model' not in self.__dict__:
            raise AttributeError(name)
        return getattr(self.model, name)

"""PARENA 的基础学习器、训练上下文和可选增广分支。

包含训练分组、SHAP 变量权重、引导响应函数、Original/Mixup/CMixup、成对模型等。"""
from __future__ import annotations
import json, hashlib
from pathlib import Path
import numpy as np
from scipy.spatial.distance import cdist
from scipy.optimize import nnls
from sklearn.preprocessing import StandardScaler, SplineTransformer, PolynomialFeatures
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import KFold
from catboost import CatBoostRegressor, Pool

def save(path,obj):
    """用途：写入 JSON，并通过临时文件替换降低写一半的风险。
    输入：path 是输出位置；obj 是可序列化内容。
    输出：写入文件，无返回值。"""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=lambda v:v.tolist() if hasattr(v,'tolist') else float(v)),encoding='utf8');tmp.replace(path)

def digest(x):
    """用途：给配置生成稳定摘要，便于缓存。
    输入：x 是可转为 JSON 的配置对象。
    输出：返回 SHA256 字符串。"""
    return hashlib.sha256(json.dumps(x,sort_keys=True,default=str).encode()).hexdigest()

def folds(groups,seed=9137,n_splits=3):
    """用途：按实体分组产生互不重叠的训练折和验证折。
    输入：groups 为每行的实体标识；seed 控制打乱；n_splits 为目标折数。
    输出：返回各折的训练索引和验证索引。"""
    groups=np.asarray(groups);ug=np.unique(groups)
    if len(ug)<3:raise ValueError('At least three independent groups are required')
    out=[]
    for a,b in KFold(min(n_splits,len(ug)),shuffle=True,random_state=seed).split(ug):
        tr=np.flatnonzero(np.isin(groups,ug[a]));va=np.flatnonzero(np.isin(groups,ug[b]))
        assert not set(groups[tr])&set(groups[va]);out.append((tr,va))
    return out

def relevance(x,y,seed):
    """用途：在当前训练折估计变量重要性。
    输入：x、y 是真实训练特征与目标；seed 控制 CatBoost。
    输出：返回归一化非负权重：90% 平均绝对 SHAP，10% 非恒定变量均匀权重。"""
    varying=np.std(x,axis=0)>1e-10
    m=CatBoostRegressor(iterations=120,depth=3,learning_rate=.06,l2_leaf_reg=5,
                        thread_count=1,random_seed=seed,verbose=False,allow_writing_files=False).fit(x,y)
    imp=np.mean(np.abs(m.get_feature_importance(Pool(x,y),type='ShapValues')[:,:-1]),axis=0)
    if imp.sum()<=1e-15:imp=varying.astype(float)
    # 两部分分别归一化：重要性主导，但给每个非恒定变量保留少量权重。
    return .9*imp/max(imp.sum(),1e-15)+.1*varying/max(varying.sum(),1)

class Guide:
    """用途：拟合便于解释和引导距离的经验响应函数 G。
    输入：form 选择样条、二次或线性；top 限制入选变量数。
    输出：predict 给出经验预测；export 导出实际系数。"""
    def __init__(self,form='spline',top=20,alpha='auto'):
        """用途：保存响应函数的形式与变量数上限。
        输入：form、top、alpha 分别控制基函数、变量数和岭回归惩罚。
        输出：返回值为 None。"""
        self.form=form;self.top=top;self.alpha=alpha
    def fit(self,x,y,importance=None,seed=728):
        """用途：选择训练内重要变量，并用岭回归拟合 G。
        输入：x、y 为当前训练折；importance 可复用已算变量权重；seed 控制拟合。
        输出：返回已拟合的 self。"""
        self.names=getattr(self,'names',[f'x{i}' for i in range(x.shape[1])])
        self.scale=StandardScaler().fit(x)
        self.imp=relevance(x,y,seed) if importance is None else importance
        self.active=np.argsort(-self.imp)[:min(self.top,max(2,len(y)//3),np.count_nonzero(np.std(x,axis=0)>1e-10))]
        z=self.scale.transform(x)[:,self.active]
        if self.form=='spline':self.basis=SplineTransformer(n_knots=4,degree=2,include_bias=False,knots='quantile',extrapolation='linear');b=self.basis.fit_transform(z)
        elif self.form=='quadratic':self.basis=PolynomialFeatures(2,include_bias=False);b=self.basis.fit_transform(z)
        else:self.basis=None;b=z
        self.bs=StandardScaler().fit(b);v=self.bs.transform(b)
        self.model=(RidgeCV(alphas=[.1,1,10,100,1000],scoring='neg_mean_absolute_error') if self.alpha=='auto' else Ridge(alpha=self.alpha)).fit(v,y)
        return self
    def predict(self,x):
        """用途：使用训练好的 G 预测。
        输入：x 是与训练特征列一致的数值表。
        输出：返回每行一个经验响应预测。"""
        z=self.scale.transform(x)[:,self.active];b=z if self.basis is None else self.basis.transform(z)
        return self.model.predict(self.bs.transform(b))
    def export(self,names=None):
        """用途：将 G 转成可审计的截距、变量与系数。
        输入：names 可指定特征名称，缺省使用模型记录名称。
        输出：返回含系数、标准化参数和样条结点的字典。"""
        names=self.names if names is None else names
        coef=self.model.coef_/self.bs.scale_;intercept=self.model.intercept_-coef@self.bs.mean_
        if self.form=='linear':terms=[f'z({names[i]})' for i in self.active]
        elif self.form=='quadratic':terms=self.basis.get_feature_names_out([f'z({names[i]})' for i in self.active]).tolist()
        else:terms=[f'B{k+1}(z({names[i]}))' for i in self.active for k in range(len(coef)//len(self.active))]
        return dict(form=self.form,intercept=float(intercept),terms=[dict(variable=t,coefficient=float(c)) for t,c in zip(terms,coef)],
                    active_features=[names[i] for i in self.active],input_means=self.scale.mean_.tolist(),input_scales=self.scale.scale_.tolist(),
                    spline_knots=[b.t.tolist() for b in self.basis.bsplines_] if self.form=='spline' else None,
                    spline_degree=2 if self.form=='spline' else None,include_bias=False,
                    interpretation='Empirical descriptor-response function; predictive association, not a causal physical law.')


class Learner:
    """用途：包装 Original、Mixup 等分支使用的下游学习器。
    输入：配置指定 KRR、CatBoost、ExtraTrees 或 Guide。
    输出：fit 后可 predict。"""
    def __init__(self,cfg,seed=728):
        """用途：保存下游学习器配置与随机种子。
        输入：cfg 为模型参数；seed 控制随机学习器。
        输出：返回值为 None。"""
        self.cfg=cfg;self.seed=seed
    def fit(self,x,y,w=None,n_real=None,importance=None):
        """用途：在真实或加权伪样本上拟合下游学习器。
        输入：x、y 为特征与标签；w 为可选样本权重；n_real 标出真实样本数。
        输出：返回已拟合的 self。"""
        self.n_real=len(y) if n_real is None else n_real;c=self.cfg
        if c['kind']=='guide':
            if len(y)!=self.n_real:raise ValueError('Guide baseline only; no weighted synthetic fit')
            self.model=Guide(c['form'],c['top']).fit(x,y,importance,self.seed);return self
        self.scale=StandardScaler().fit(x[:self.n_real]);z=self.scale.transform(x)
        self.mean=float(np.mean(y[:self.n_real]));self.sd=max(float(np.std(y[:self.n_real])),1e-9);yy=(y-self.mean)/self.sd
        if c['kind']=='krr':self.model=KernelRidge(kernel='rbf',alpha=c['alpha'],gamma=c['gamma']/x.shape[1])
        elif c['kind']=='cat':self.model=CatBoostRegressor(iterations=c.get('iterations',300),depth=c['depth'],loss_function=c.get('loss','RMSE'),learning_rate=.055,l2_leaf_reg=5,thread_count=1,random_seed=self.seed,verbose=False,allow_writing_files=False)
        elif c['kind']=='rf':self.model=RandomForestRegressor(n_estimators=c.get('trees',140),min_samples_leaf=c.get('leaf',2),max_features=c.get('max_features',.8),n_jobs=1,random_state=self.seed)
        elif c['kind']=='hist':self.model=HistGradientBoostingRegressor(max_iter=c.get('iterations',160),max_leaf_nodes=c.get('leaves',15),min_samples_leaf=c.get('leaf',8),l2_regularization=c.get('l2',1.),learning_rate=.06,early_stopping=False,random_state=self.seed)
        elif c['kind']=='et':self.model=ExtraTreesRegressor(n_estimators=c.get('trees',140),min_samples_leaf=c.get('leaf',1),max_features=c.get('max_features',1.),n_jobs=1,random_state=self.seed)
        else:raise ValueError(f"Unknown learner kind: {c['kind']}")
        w=np.ones(len(y)) if w is None else np.asarray(w);w=w*self.n_real/w.sum()
        self.model.fit(z,yy,sample_weight=w);return self
    def predict(self,x):
        """用途：将下游模型预测换回原目标尺度。
        输入：x 为待预测特征表。
        输出：返回每行一个性质预测。"""
        if self.cfg['kind']=='guide':return self.model.predict(x)
        return self.model.predict(self.scale.transform(x))*self.sd+self.mean

class Context:
    """用途：封装当前训练折，并缓存标准化、变量权重和引导模型。
    输入：x、y 是真实训练数据；groups 是实体分组；names 是列名。
    输出：供其他分支共享训练内拟合信息。"""
    def __init__(self,x,y,groups=None,seed=728,names=None,standardize=False,remove_outliers=False):
        """用途：保存训练数据，拟合特征标准化，并建立训练内缓存。
        输入：x、y、groups、seed、names 都只对应当前训练折。
        输出：返回值为 None。"""
        from .preprocessing import NumericPreprocessor
        self.raw_x=np.asarray(x,float)
        self.standardize=standardize;self.remove_outliers=remove_outliers
        self.preprocessor=NumericPreprocessor(standardize).fit(self.raw_x)
        self.x=self.preprocessor.transform(self.raw_x);x=self.x
        self.y=np.asarray(y,float);self.seed=seed;self.n=len(y)
        self.groups=np.arange(len(y)).astype(str) if groups is None else np.asarray(groups)
        self.names=names if names is not None else [f'x{i}' for i in range(x.shape[1])]
        self.categorical_indices=[i for i,s in enumerate(self.names) if str(s).startswith(('salt_','space_group_'))]
        self.scale=StandardScaler().fit(x);self.z=self.scale.transform(x);self.sd=max(float(np.std(y)),1e-9)
        self.cache={};self._imp=None;self._teacher=None
    @property
    def importance(self):
        """用途：按需计算并缓存当前训练折的变量权重。
        输入：无额外输入。
        输出：返回归一化变量权重向量。"""
        if self._imp is None:self._imp=relevance(self.x,self.y,self.seed)
        return self._imp
    def guide(self,form='spline',top=20):
        """用途：按需拟合并缓存指定形式的经验响应函数 G。
        输入：form 是函数形式；top 是最多使用的变量数。
        输出：返回 Guide 对象。"""
        key=('guide',form,top)
        if key not in self.cache:self.cache[key]=Guide(form,top).fit(self.x,self.y,self.importance,self.seed)
        return self.cache[key]
    def distance(self,weighted=True):
        """用途：计算真实训练样本之间的标准化距离。
        输入：weighted 指是否使用训练内变量权重。
        输出：返回方阵距离矩阵。"""
        key=('distance',weighted)
        if key not in self.cache:
            weights=self.importance if weighted else np.ones(self.x.shape[1])/self.x.shape[1]
            self.cache[key]=cdist(self.z*np.sqrt(weights),self.z*np.sqrt(weights))
        return self.cache[key]
    def teacher(self):
        """用途：按需拟合并缓存伪标签教师模型。
        输入：无额外输入。
        输出：返回 Teacher 对象。"""
        if self._teacher is None:self._teacher=Teacher().fit(self)
        return self._teacher

class Teacher:
    """用途：伪标签候选使用的训练内组合教师。
    输入：只读取当前训练折；先生成折外预测，再校准组合。
    输出：predict 返回教师预测和可选模型分歧。"""
    def fit(self,ctx):
        """用途：用分组折外预测拟合教师组合与局部插值信任程度。
        输入：ctx 为当前真实训练折。
        输出：返回已拟合的 self，并保存折外误差和组合权重。"""
        configs=[dict(kind='guide',form='spline',top=20),dict(kind='guide',form='quadratic',top=10),
                 dict(kind='krr',alpha=.1,gamma=.3),dict(kind='cat',depth=4,iterations=200,loss='RMSE')]
        oof=np.zeros((ctx.n,len(configs)));local=np.zeros(ctx.n)
        for f,(tr,va) in enumerate(folds(ctx.groups,ctx.seed+193)):
            xt,yt=ctx.x[tr],ctx.y[tr];imp=relevance(xt,yt,ctx.seed+f)
            for j,c in enumerate(configs):oof[va,j]=Learner(c,ctx.seed+f).fit(xt,yt,importance=imp).predict(ctx.x[va])
            sc=StandardScaler().fit(xt);dist=cdist(sc.transform(ctx.x[va])*np.sqrt(imp),sc.transform(xt)*np.sqrt(imp))
            bw=np.maximum(np.median(np.sort(dist,axis=1)[:,:max(2,int(np.sqrt(len(tr))))],axis=1),1e-6)
            prob=np.exp(-(dist-dist.min(1)[:,None])/bw[:,None]);prob/=prob.sum(1)[:,None]
            local[va]=prob@yt
        # 非负组合权重只用训练内折外预测拟合。
        weights=nnls((oof-ctx.y.mean())/ctx.sd,(ctx.y-ctx.y.mean())/ctx.sd)[0]
        if weights.sum()<1e-10:weights=np.eye(len(configs))[np.argmin(np.mean(abs(oof-ctx.y[:,None]),axis=0))]
        weights/=weights.sum();self.weights=weights;self.oof=oof@weights
        self.errors=self.oof-ctx.y; self.oof_mae=float(np.mean(abs(self.errors)))
        # 用被留出的真实训练行比较教师预测与局部插值，估计信任程度。
        delta=self.oof-local;den=delta@delta
        self.trust=float(np.clip(delta@(ctx.y-local)/max(den,1e-12),0,1))
        self.models=[Learner(c,ctx.seed).fit(ctx.x,ctx.y,importance=ctx.importance) for c in configs]
        self.info={'weights':weights.tolist(),'oof_mae':self.oof_mae,'trust':self.trust,'configs':configs}
        return self
    def predict(self,x,return_spread=False):
        """用途：由教师的多个基学习器组合预测。
        输入：x 为待预测特征；return_spread 控制是否输出模型分歧。
        输出：返回预测；可选再返回分歧量。"""
        p=np.column_stack([m.predict(x) for m in self.models]);mean=p@self.weights
        if return_spread:return mean,np.sqrt(((p-mean[:,None])**2)@self.weights)
        return mean

def neighborhood(dist,q=.8,radius=.5,exclude_self=False):
    """用途：候选分支使用的距离加权邻居规则。
    输入：dist 为距离矩阵；q 为累计质量门槛；radius 控制带宽。
    输出：返回各行的邻居索引和归一化权重。"""
    d=np.asarray(dist).copy()
    if exclude_self:np.fill_diagonal(d,np.inf)
    out=[]
    for row in d:
        order=np.argsort(row);order=order[np.isfinite(row[order])]
        if len(order)==0:
            out.append((np.array([],dtype=int),np.array([],dtype=float)));continue
        cap=min(len(order),max(2,int(np.ceil(3*np.sqrt(len(row))))));order=order[:cap]
        bw=max(float(np.median(row[order]))*radius,1e-8)
        p=np.exp(-(row[order]-row[order[0]])/bw);p/=p.sum()
        k=min(len(order),int(np.searchsorted(np.cumsum(p),q))+1)
        out.append((order[:k],p[:k]/p[:k].sum()))
    return out

def synthetic(ctx,cfg,method):
    """用途：为 Mixup、CMixup 或 PARENA 伪标签分支构造训练用样本。
    输入：ctx 为真实训练折；cfg 为插值和伪标签配置；method 指分支。
    输出：返回组合后的特征、标签、样本权重及父样本记录；不是新实测数据。"""
    # 插值数据与下游学习器无关；相同增广规则共享一次生成结果。
    key=('synth',method,digest({k:v for k,v in cfg.items() if k not in ['model','family','residual_model']}))
    if key in ctx.cache:return ctx.cache[key]
    rng=np.random.default_rng(ctx.seed+812);n=ctx.n;count=min(cfg.get('ratio',2)*n,768)
    guided=method=='PARENA';pool=count*3 if guided else count
    if guided:
        dist=ctx.distance(cfg.get('weighted',True)).copy()
        if ctx.categorical_indices:
            cats=ctx.x[:,ctx.categorical_indices]
            compatible=np.all(cats[:,None,:]==cats[None,:,:],axis=2);dist[~compatible]=np.inf
        hood=neighborhood(dist,cfg.get('q',.8),cfg.get('radius',.5),True)
        supported=np.array([len(idx)>0 for idx,p in hood])
        if not supported.any():
            result=(ctx.x.copy(),ctx.y.copy(),np.ones(n),dict(count=0,label=cfg.get('label'),parents=[],parent_weights=[],unsupported_anchors=n))
            ctx.cache[key]=result;return result
        # 没有可用邻居的锚点保留原位置，并记录下来；
        # 不能把它当作新生成的化学结构。
        hood=[(idx,p) if len(idx) else (np.array([i]),np.ones(1)) for i,(idx,p) in enumerate(hood)]
    sx=[];linear=[];parents=[];weights=[]
    for t in range(pool):
        i=t%n
        if guided:
            idx,prob=hood[i]
            if cfg.get('multi',False):w=rng.dirichlet(np.maximum(prob*3,1e-3))
            else:idx=np.array([rng.choice(idx,p=prob)]);w=np.ones(1)
        else:
            prob=np.ones(n)
            if method=='CMixup':
                z=-.5*((ctx.y-ctx.y[i])/(ctx.sd*cfg.get('bandwidth',.5)))**2;z[i]=-np.inf
                prob=np.exp(z-np.max(z))
            prob[i]=0;prob/=prob.sum();idx=np.array([rng.choice(n,p=prob)]);w=np.ones(1)
        lam=rng.beta(cfg.get('alpha',.4),cfg.get('alpha',.4))
        if guided and cfg.get('near',False):lam=1-.25*(1-lam)
        p=np.r_[i,idx];ww=np.r_[lam,(1-lam)*w]
        sx.append(ww@ctx.x[p]);linear.append(ww@ctx.y[p]);parents.append(p);weights.append(ww)
    sx=np.array(sx);linear=np.array(linear);sy=linear.copy();score=np.zeros(pool)
    if guided and cfg.get('generation')=='tangent':
        g=ctx.guide();grad=np.zeros_like(ctx.x);eps=1e-3
        for j in g.active:
            xp=ctx.x.copy();xm=ctx.x.copy();xp[:,j]+=eps*ctx.scale.scale_[j];xm[:,j]-=eps*ctx.scale.scale_[j]
            grad[:,j]=(g.predict(xp)-g.predict(xm))/(2*eps)
        centers=np.arange(pool)%n;delta=ctx.scale.transform(sx)-ctx.z[centers];gg=grad[centers]
        delta-=np.sum(delta*gg,axis=1)[:,None]*gg/np.maximum(np.sum(gg*gg,axis=1)[:,None],1e-12)
        if ctx.categorical_indices:delta[:,ctx.categorical_indices]=0
        sx=ctx.x[centers]+cfg.get('step',.5)*delta*ctx.scale.scale_
        sx=np.clip(sx,ctx.x.min(0),ctx.x.max(0))
    label=cfg.get('label','linear');info={}
    if guided and label!='linear':
        if label.startswith('local'):
            active=np.argsort(-ctx.importance)[:min(12,max(2,n//6),ctx.x.shape[1])]
            z=ctx.z[:,active];zs=ctx.scale.transform(sx)[:,active];sy=np.empty(pool)
            d=ctx.distance(True)
            slopes=[]
            base=ctx.guide() if label=='local_residual' else None
            target=ctx.y-(base.predict(ctx.x) if base is not None else 0)
            for i in range(n):
                order=np.argsort(d[i])[:min(n,max(12,int(np.sqrt(n)*3)))]
                w=np.exp(-d[i,order]/max(np.median(d[i,order]),1e-6))
                # 局部一阶响应来自实测邻居，不能用待预测标签拟合。
                model=Ridge(alpha=cfg.get('local_alpha',1.)).fit(z[order]-z[i],target[order]-target[i],sample_weight=w)
                positions=np.arange(i,pool,n)
                sy[positions]=target[i]+model.predict(zs[positions]-z[i])
                score[positions]=np.sqrt(np.average((model.predict(z[order]-z[i])-(target[order]-target[i]))**2,weights=w))/ctx.sd
                slopes.append(model.coef_.tolist())
            if base is not None:sy+=base.predict(sx)
            info['local_slopes']=slopes;info['local_features']=active.tolist()
        elif label=='anchor_transport':
            g=ctx.guide();centers=np.arange(pool)%n;sy=ctx.y[centers]+g.predict(sx)-g.predict(ctx.x[centers])
            score=np.abs(g.predict(sx)-g.predict(ctx.x[centers]))/ctx.sd
        elif label=='invariant':
            centers=np.arange(pool)%n;sy=ctx.y[centers].copy()
            score=np.abs(ctx.guide().predict(sx)-ctx.guide().predict(ctx.x[centers]))/ctx.sd
        elif label.startswith('guide'):
            model=ctx.guide();gp=model.predict(ctx.x);gs=model.predict(sx)
            pg=np.array([w@gp[p] for p,w in zip(parents,weights)])
            if label=='guide_transport':sy=linear+gs-pg
            elif label=='guide_direct':sy=gs
            else:sy=.5*(linear+gs)
            rr=ctx.y-gp;score=np.array([np.sqrt(w@((rr[p]-w@rr[p])**2)) for p,w in zip(parents,weights)])/ctx.sd
        else:
            teacher=ctx.teacher();gp=teacher.predict(ctx.x);gs,spread=teacher.predict(sx,True)
            pg=np.array([w@gp[p] for p,w in zip(parents,weights)])
            residual=np.array([w@(-teacher.errors[p]) for p,w in zip(parents,weights)])
            if label=='teacher_direct':sy=gs
            elif label=='teacher_transport':sy=linear+gs-pg
            elif label=='teacher_calibrated':sy=teacher.trust*gs+(1-teacher.trust)*linear
            elif label=='teacher_local_residual':sy=gs+.5*residual
            score=spread/ctx.sd+np.array([w@np.abs(teacher.errors[p]) for p,w in zip(parents,weights)])/ctx.sd
            info['teacher']=teacher.info
    if guided:
        displacement=np.sqrt(np.sum((ctx.scale.transform(sx)-ctx.z[np.arange(pool)%n])**2*ctx.importance,axis=1))
        score+=.1*displacement
        # 先按锚点保留候选，避免全部伪样本集中在少数分子附近。
        keep=[]
        per=max(1,count//n)
        for i in range(n):
            candidates=np.arange(i,pool,n)
            keep.extend(candidates[np.argsort(score[candidates])[:per]])
        keep=np.array([k for k in keep[:count] if supported[k%n]],int);sx=sx[keep];sy=sy[keep]
        parents=[parents[i] for i in keep];weights=[weights[i] for i in keep]
    ww=np.r_[np.ones(n),np.full(len(sy),cfg.get('mass',1)*n/len(sy))]
    info.update(count=len(sy),label=label,mean_label_shift=float(np.mean(abs(sy-linear[:len(sy)]))) if not guided else None,
                generation=cfg.get('generation','mix'),
                parents=[p.tolist() for p in parents],parent_weights=[w.tolist() for w in weights],
                effective_neighbors=float(np.median([1/np.sum((w[1:]/w[1:].sum())**2) if w[1:].sum()>1e-12 else 0. for w in weights])))
    result=(np.vstack([ctx.x,sx]),np.r_[ctx.y,sy],ww,info);ctx.cache[key]=result;return result

class Augmented:
    """用途：把真实样本与可选伪样本送入下游学习器。
    输入：ctx、cfg、method 决定 Original、Mixup、CMixup 或伪标签方案。
    输出：predict 返回拟合后预测。"""
    def __init__(self,ctx,cfg,method):
        """用途：生成或读取训练样本，再拟合下游模型。
        输入：ctx 为当前训练折；cfg 为模型和增广参数；method 为分支名称。
        输出：保存拟合模型与伪样本来源。"""
        self.cfg=cfg;self.guide=None;self.teacher=None;self.info={}
        if method=='Teacher':self.teacher=ctx.teacher();self.info=self.teacher.info;return
        if method=='Original':xx,yy,ww=ctx.x,ctx.y,np.ones(ctx.n)
        else:xx,yy,ww,self.info=synthetic(ctx,cfg,method)
        if cfg.get('residual_model',False):
            self.guide=ctx.guide();yy=yy-self.guide.predict(xx)
        self.model=Learner(cfg['model'],ctx.seed).fit(xx,yy,ww,ctx.n,importance=ctx.importance if cfg['model']['kind']=='guide' else None)
    def predict(self,x):
        """用途：使用增广分支的模型预测。
        输入：x 是待预测特征表。
        输出：返回每行一个预测值。"""
        if self.teacher is not None:return self.teacher.predict(x)
        p=self.model.predict(x)
        return p+(self.guide.predict(x) if self.guide is not None else 0)

class RiskAwarePairModel:
    """用途：成对差值候选，可选经验响应引导和误差风险修正。
    输入：ctx 为训练折；cfg 为成对配置；method 区分 PARENA_Pair 和 PADRE 风格。
    输出：predict 聚合真实参考样本的投票。"""
    def __init__(self,ctx,cfg,method='PARENA_Pair'):
        """用途：从真实训练样本生成成对关系并拟合差值模型。
        输入：ctx 为真实训练折；cfg 控制邻域、学习器和可选风险修正。
        输出：保存成对模型、父样本和诊断记录。"""
        self.cfg=cfg;self.x=ctx.x;self.y=ctx.y;self.scale=ctx.scale;self.z=ctx.z;self.sd=ctx.sd
        self.guided=method=='PARENA_Pair';self.guide=ctx.guide() if self.guided and cfg.get('guide',False) else None
        self.imp=ctx.importance if self.guided and cfg.get('weighted',True) else np.ones(ctx.x.shape[1])/ctx.x.shape[1]
        # 仅使用当前训练折计算的 SHAP 权重选择成对表示。
        self.active=np.argsort(-ctx.importance)[:min(cfg.get('top',ctx.x.shape[1]),ctx.x.shape[1])] if self.guided else np.arange(ctx.x.shape[1])
        self.r=ctx.y-(self.guide.predict(ctx.x) if self.guide is not None else 0)
        rng=np.random.default_rng(ctx.seed+516);n=ctx.n
        if self.guided:
            hood=[];coordinates=ctx.z*np.sqrt(self.imp)
            for start in range(0,n,128):
                dist=cdist(coordinates[start:start+128],coordinates)
                dist[np.arange(len(dist)),np.arange(start,start+len(dist))]=np.inf
                hood.extend(neighborhood(dist,cfg.get('q',.95),cfg.get('radius',1.)))
        maxpairs=min(6000,n*cfg.get('pairs_per_point',24));edges=[]
        for i in range(n):
            if self.guided and cfg.get('local_pairs',True):idx,p=hood[i]
            else:idx=np.delete(np.arange(n),i);p=np.ones(len(idx))/len(idx)
            take=min(len(idx),max(1,maxpairs//n));chosen=rng.choice(idx,size=take,replace=False,p=p)
            edges.extend((i,int(j)) for j in chosen)
        edges=np.array(edges,int);edges=np.vstack([edges,edges[:,::-1]])
        a,b=edges.T;v=self.representation(ctx.x[a],ctx.x[b]);target=self.r[a]-self.r[b]
        self.pairscale=StandardScaler().fit(v);v=self.pairscale.transform(v)
        c=cfg['model']
        if c['kind']=='cat':self.model=CatBoostRegressor(iterations=c.get('iterations',260),depth=c.get('depth',5),learning_rate=.055,l2_leaf_reg=5,loss_function='RMSE',thread_count=1,random_seed=ctx.seed,verbose=False,allow_writing_files=False)
        else:self.model=ExtraTreesRegressor(n_estimators=c.get('trees',120),min_samples_leaf=c.get('leaf',2),max_features=c.get('max_features',1.),n_jobs=1,random_state=ctx.seed)
        self.model.fit(v,target/ctx.sd)
        self.info=dict(pair_count=len(edges),unique_real_count=n,parents=edges.tolist(),active_indices=self.active.tolist(),
                       guide=self.guide.export(ctx.names) if self.guide is not None else None,
                       importance=self.imp.tolist(),label='exact observed y_i-y_j, with optional exact guide-residual subtraction')
        self.risk_model=None
        if self.guided and cfg.get('risk',False):
            self.risk_model=fit_anchor_risk(ctx,cfg)
            self.info['risk_formula']=self.risk_model['export']
    def representation(self,a,b):
        """用途：将样本对转为差值或差值加位置的特征。
        输入：a、b 为行数对应的特征表。
        输出：返回成对模型使用的数值矩阵。"""
        aa=self.scale.transform(a)[:,self.active];bb=self.scale.transform(b)[:,self.active]
        kind=self.cfg.get('representation','diff_mid')
        if kind=='diff':return aa-bb
        if kind=='concat':return np.c_[aa,bb,aa-bb]
        return np.c_[aa-bb,(aa+bb)/2]
    def predict(self,x):
        """用途：用成对模型在参考样本上投票预测。
        输入：x 为待预测样本；风险模型可降低高误差参考样本权重。
        输出：返回每行一个预测值，并保存有效参考数统计。"""
        x=np.asarray(x,float);chunks=[];effective=[]
        for start in range(0,len(x),128):
            chunks.append(self._predict_batch(x[start:start+128]));effective.extend(self._effective_anchor_counts)
        if effective:self.info['prediction_effective_anchor_median']=float(np.median(effective))
        return np.concatenate(chunks) if chunks else np.empty(0)
    def _predict_batch(self,x):
        """用途：在一个小批量中完成参考投票，限制临时成对特征的内存。
        输入：最多 128 行查询特征；输出：该批预测和供汇总的有效参考数。"""
        dist=cdist(self.scale.transform(x)*np.sqrt(self.imp),self.z*np.sqrt(self.imp))
        if self.guided:hood=neighborhood(dist,self.cfg.get('q',.95),self.cfg.get('radius',1.))
        else:hood=[(np.arange(len(self.y)),np.ones(len(self.y))/len(self.y)) for _ in x]
        query=[];anchors=[];slices=[];start=0
        for i,(idx,w) in enumerate(hood):
            query.extend([i]*len(idx));anchors.extend(idx);slices.append((start,start+len(idx),w));start+=len(idx)
        query=np.array(query);anchors=np.array(anchors);aa=x[query];bb=self.x[anchors]
        pos=self.model.predict(self.pairscale.transform(self.representation(aa,bb)))
        neg=self.model.predict(self.pairscale.transform(self.representation(bb,aa)))
        votes=self.r[anchors]+.5*(pos-neg)*self.sd
        risks=None
        if self.risk_model is not None:
            rr=self.risk_model;zdelta=np.abs(self.scale.transform(aa)-self.scale.transform(bb))[:,rr['active']]
            risks=np.exp(np.clip(rr['model'].predict(zdelta),-4,3))
        out=[];eff=[]
        for lo,hi,w in slices:
            v=votes[lo:hi]
            if risks is not None:
                w=w/np.maximum(risks[lo:hi],.02)**self.cfg.get('risk_power',1.)
                w/=w.sum()
            if self.guided and self.cfg.get('consistency',True):
                median=float(np.median(v));scale=max(float(np.median(abs(v-median)))*1.4826,.1*self.sd)
                w=w/(1+((v-median)/scale)**2);w/=w.sum()
            out.append(w@v);eff.append(1/(w@w))
        self._effective_anchor_counts=eff
        p=np.array(out)
        return p+(self.guide.predict(x) if self.guide is not None else 0)

def fit_anchor_risk(ctx,cfg):
    """用途：只在训练内估计参考样本投票的经验误差风险。
    输入：ctx 为真实训练折；cfg 为成对候选配置。
    输出：返回风险模型及可导出的系数；不是校准预测区间。"""
    base={k:v for k,v in cfg.items() if k not in ['risk','risk_power']}
    key=('anchor_risk',digest(base))
    if key in ctx.cache:return ctx.cache[key]
    active=np.argsort(-ctx.importance)[:min(16,max(2,ctx.n//5),ctx.x.shape[1])]
    meta_x=[];meta_y=[];lineage=[]
    for f,(tr,va) in enumerate(folds(ctx.groups,ctx.seed+517)):
        sub=Context(ctx.x[tr],ctx.y[tr],ctx.groups[tr],ctx.seed+f,ctx.names)
        subcfg=json.loads(json.dumps(base));subcfg['pairs_per_point']=min(12,base.get('pairs_per_point',24))
        if subcfg['model']['kind']=='et':subcfg['model']['trees']=60
        else:subcfg['model']['iterations']=160
        model=RiskAwarePairModel(sub,subcfg)
        rng=np.random.default_rng(ctx.seed+f);anchor_indices=rng.choice(len(tr),min(len(tr),32),replace=False)
        qi=np.repeat(va,len(anchor_indices));ai=np.tile(tr[anchor_indices],len(va))
        aa=ctx.x[qi];bb=ctx.x[ai]
        pos=model.model.predict(model.pairscale.transform(model.representation(aa,bb)))
        neg=model.model.predict(model.pairscale.transform(model.representation(bb,aa)))
        pred=model.r[np.tile(anchor_indices,len(va))]+.5*(pos-neg)*model.sd
        if model.guide is not None:pred+=model.guide.predict(aa)
        meta_x.append(np.abs(ctx.scale.transform(aa)-ctx.scale.transform(bb))[:,active])
        meta_y.append(np.log(np.abs(pred-ctx.y[qi])/ctx.sd+.03))
        lineage.append({'validation_indices':va.tolist(),'training_indices':tr.tolist(),'pairs':len(qi)})
    xx=np.vstack(meta_x);yy=np.concatenate(meta_y)
    model=Ridge(alpha=max(10.,len(xx)*.1)).fit(xx,yy)
    out=dict(active=active,model=model,export=dict(
        formula='estimated normalized absolute error = exp(b0 + sum b_j * abs(z_j(query)-z_j(anchor)))',
        intercept=float(model.intercept_),terms=[dict(feature=ctx.names[i],coefficient=float(c)) for i,c in zip(active,model.coef_)],
        calibration_pairs=len(yy),independent_real_rows=ctx.n,internal_group_folds=lineage,
        caveat='Empirical cross-fitted error score, not a calibrated prediction interval or causal law.'))
    ctx.cache[key]=out;return out

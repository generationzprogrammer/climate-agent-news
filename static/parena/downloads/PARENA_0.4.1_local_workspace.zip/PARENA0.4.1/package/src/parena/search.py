"""在固定提议预算内，自动分配不同候选生成操作的尝试次数。

生成操作、身份检查和性质评价由使用者提供；本模块记录每次真实尝试，
依据新候选的预测达标率分配后续预算。预测达标仍需要独立实测验证。
"""
import math
import numpy as np


class PARENASearch:
    """用途：用预测反馈和探索奖励，自动分配候选生成预算。
    输入：proposers 为命名生成函数；identify 检查候选并返回唯一身份；
    evaluate 批量返回 identity、predicted_hit、rank_score 及可选性质。
    输出：run 返回候选档案、逐次提议记录、预算分配历史和结束状态。
    """

    def __init__(self, max_attempts=10000, batch_size=200, exploration=2.,
                 random_state=728, allocation='ucb'):
        """用途：固定尝试预算、批量大小和探索规则。
        输入：max_attempts 包括失败和重复提议；allocation 可取 ucb 或 uniform。
        输出：构造时保存参数，不执行提议或性质预测。
        """
        self.max_attempts=max_attempts;self.batch_size=batch_size
        self.exploration=exploration;self.random_state=random_state;self.allocation=allocation

    def run(self, proposers, identify, evaluate, excluded=()):
        """用途：执行固定预算搜索，并保留可复核的全部尝试记录。
        输入：生成函数接收 rng 和当前 archive，返回含 candidate 的字典；
        真实提议失败可返回 candidate=None，生成器耗尽应抛出 StopIteration。
        identify 返回 None 表示不合格结构；excluded 是预先排除的身份集合。
        输出：字典包含 archive、raw_attempts、allocation_history、status。
        每个新身份只评价一次；生成器耗尽时切换操作，全部耗尽时提前结束。
        """
        if self.allocation not in ['ucb','uniform']:raise ValueError('allocation must be ucb or uniform')
        if self.max_attempts<1 or self.batch_size<1 or not proposers:raise ValueError('Positive budgets and at least one proposer are required')
        names=list(proposers);rng=np.random.default_rng(self.random_state)
        pulls={n:0 for n in names};reward={n:0. for n in names};active=set(names)
        seen=set(excluded);archive={};raw=[];history=[];batch_index=0
        while len(raw)<self.max_attempts and active:
            available=[n for n in names if n in active]
            untried=[n for n in available if pulls[n]==0]
            if untried:arm=untried[0]
            elif self.allocation=='uniform':arm=available[batch_index%len(available)]
            else:
                values={n:reward[n]/pulls[n]+math.sqrt(self.exploration*math.log(len(raw)+1)/pulls[n]) for n in available}
                arm=max(available,key=lambda n:values[n])
            proposed=[];attempts=0
            for _ in range(min(self.batch_size,self.max_attempts-len(raw))):
                try:item=dict(proposers[arm](rng,archive))
                except StopIteration:
                    active.remove(arm);break
                candidate=item.get('candidate');identity=identify(candidate) if candidate is not None else None
                novel=identity is not None and identity not in seen
                raw.append(dict(item,raw_attempt=len(raw)+1,proposal_arm=arm,identity=identity,first_novel_admissible=novel))
                if novel:
                    seen.add(identity);proposed.append(dict(item,identity=identity,candidate=identity))
                attempts+=1
            hits=0
            if proposed:
                evaluated=evaluate([p['candidate'] for p in proposed])
                lookup={r['identity']:r for r in evaluated}
                if set(lookup)!=set(p['identity'] for p in proposed):raise ValueError('Evaluator identities do not match proposed candidates')
                for p in proposed:
                    record=dict(p,**lookup[p['identity']]);archive[p['identity']]=record
                    hits+=int(record['predicted_hit'])
            pulls[arm]+=attempts;reward[arm]+=hits
            history.append(dict(batch=batch_index,arm=arm,attempts=attempts,new_candidates=len(proposed),new_predicted_hits=hits,
                cumulative_raw=len(raw),cumulative_candidates=len(archive),cumulative_predicted_hits=sum(bool(r['predicted_hit']) for r in archive.values())))
            batch_index+=1
        return dict(archive=list(archive.values()),raw_attempts=raw,allocation_history=history,
                    arm_attempts=pulls,arm_predicted_hits=reward,status='complete' if len(raw)==self.max_attempts else 'generators_exhausted',
                    evidence='Predicted qualification; independent experimental validation required')

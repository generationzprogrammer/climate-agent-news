"""可复现的训练内候选选择与外层分组评估。

候选池来自包内 frozen_policy.json。评估数据由调用者提供 NPZ 路径，
结果写入调用者指定目录；缓存校验绑定数据、分组、种子、配置和代码。
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np

from .estimators import Context, digest, folds
from .transport import fit, safe_save


def load_policy():
    """用途：读取随包发布的完整候选策略。
    输入：无参数。
    输出：包含版本、核心候选和三个基础分支候选池的字典。
    """
    path = Path(__file__).with_name('frozen_policy.json')
    return json.loads(path.read_text(encoding='utf8'))


def baseline_pools(policy=None):
    """用途：取得 Original、Mixup、CMixup 三个分支的候选。
    输入：policy 可指定完整策略；None 使用包内策略。
    输出：按固定顺序排列的候选池字典，保持分支组合顺序稳定。
    """
    policy = load_policy() if policy is None else policy
    if 'pool' not in policy or 'version' not in policy or 'baseline_pools' not in policy:
        raise ValueError('Policy requires version, pool and baseline_pools')
    return {name: policy['baseline_pools'][name] for name in ['Original', 'Mixup', 'CMixup']}


def supported(cfg, ctx):
    """用途：检查教师或风险模型是否有足够分组完成额外内层拟合。
    输入：cfg 为候选配置，ctx 为当前训练数据。
    输出：布尔值；组数不足的嵌套候选会记录为 unavailable。
    """
    if cfg.get('model',{}).get('kind')=='krr' and ctx.n>2048:return False
    if cfg.get('family')=='pseudo' and ctx.n>2048:return False
    nested = cfg.get('risk', False) or cfg.get('anchor_reliability',False) or str(cfg.get('label', '')).startswith('teacher')
    return not nested or all(len(np.unique(ctx.groups[tr])) >= 3 for tr, _ in folds(ctx.groups, ctx.seed))


def context_signature(ctx):
    """用途：给当前训练数据及执行代码生成缓存身份。
    输入：ctx 包含特征、标签、分组、特征名和随机种子。
    输出：SHA256 字符串；修改数据或代码后禁止复用不匹配缓存。
    """
    key = ('cache_signature',)
    if key not in ctx.cache:
        h = hashlib.sha256()
        for array in [ctx.raw_x, ctx.y]:
            a = np.ascontiguousarray(array, dtype='<f8')
            h.update(str(a.shape).encode())
            h.update(a.tobytes())
        h.update(digest([ctx.groups.tolist(), list(ctx.names), ctx.seed, ctx.standardize, ctx.remove_outliers]).encode())
        for name in ['estimators.py', 'transport.py', 'study.py', 'api.py', 'preprocessing.py']:
            h.update(Path(__file__).with_name(name).read_bytes())
        ctx.cache[key] = h.hexdigest()
    return ctx.cache[key]


def cv_config(ctx, cfg, path):
    """用途：对一个候选执行三折分组交叉验证并缓存折外预测。
    输入：ctx 为当前训练折，cfg 为配置，path 为 JSON 缓存位置。
    输出：返回 config、status、fold_mae、cv_mae 和 oof 等记录。
    cv_mae 是三个折 MAE 的等权平均；pooled_mae 是全部折外行的 MAE。
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    signature = digest([context_signature(ctx), cfg])
    if path.exists():
        ans = json.loads(path.read_text(encoding='utf8'))
        if ans.get('signature') != signature or ans['config'] != cfg:
            raise ValueError(f'Cache does not match the current data/configuration: {path.name}')
        return ans
    if not supported(cfg, ctx):
        ans = dict(config=cfg, signature=signature, status='unavailable',
                   reason='Independent-group or declared CPU resource limit prevents this candidate')
        safe_save(path, ans)
        return ans
    key = ('cv3', ctx.seed)
    if key not in ctx.cache:
        fs = folds(ctx.groups, ctx.seed)
        ctx.cache[key] = (fs, [Context(ctx.raw_x[a], ctx.y[a], ctx.groups[a], ctx.seed+f*101, ctx.names, ctx.standardize, ctx.remove_outliers)
                              for f, (a, _) in enumerate(fs)])
    fs, contexts = ctx.cache[key]
    pred, scores, start = np.empty(ctx.n), [], time.perf_counter()
    preprocessing_audit=[]
    for f, (_, va) in enumerate(fs):
        fc=contexts[f]
        preprocessing_audit.append(dict(fold=f,training_rows=fc.n,
            flagged_training_rows=int(fc.preprocessor.outliers(fc.raw_x).sum()),
            removal_enabled=bool(fc.remove_outliers),validation_rows=len(va),
            all_missing_columns=list(fc.preprocessor.empty_columns_)))
        fp = path.with_name(path.stem+f'_fold{f}.npz')
        if fp.exists():
            with np.load(fp, allow_pickle=False) as cached:
                if str(cached['signature']) != signature or not np.array_equal(cached['validation'], va):
                    raise ValueError(f'Fold cache mismatch: {fp.name}')
                p = cached['prediction']
        else:
            model = fit(contexts[f], cfg)
            p = model.predict(ctx.raw_x[va])
            tmp = fp.with_suffix('.tmp.npz')
            np.savez_compressed(tmp, validation=va, prediction=p, signature=signature)
            tmp.replace(fp)
        if p.shape != (len(va),) or not np.isfinite(p).all():
            raise ValueError('Candidate returned invalid predictions')
        pred[va] = p
        scores.append(float(np.mean(abs(p-ctx.y[va]))))
    ans = dict(config=cfg, signature=signature, status='complete',
               cv_mae=float(np.mean(scores)), pooled_mae=float(np.mean(abs(pred-ctx.y))),
               fold_mae=scores, oof=pred.tolist(), seconds=time.perf_counter()-start,
               fold_preprocessing=preprocessing_audit)
    safe_save(path, ans)
    return ans


def select_diverse(results, k=3):
    """用途：按验证 MAE 选取最多 k 个结构不同的配置。
    输入：results 为候选验证记录，k 为数量上限。
    输出：选中记录列表；以家族、学习器、表示及引导方式区分结构。
    此处未按预测相关系数筛选，候选间相关性不保证低于某个阈值。
    """
    usable = sorted((r for r in results if r['status'] == 'complete'), key=lambda r: r['cv_mae'])
    chosen, families = [], set()
    for result in usable:
        c = result['config']
        family = (c.get('family'), c.get('model', {}).get('kind'), c.get('geometry'),
                  c.get('representation'), bool(c.get('residual_model')), bool(c.get('guide')))
        if family not in families:
            chosen.append(result)
            families.add(family)
        if len(chosen) == k:
            break
    return chosen


def select_complementary(results, y, groups, k=3):
    """用途：优先选择验证误差互补、组合后确实降低训练侧误差的成员。
    输入：候选的训练内折外预测、真实训练标签及分组；k 为组合大小上限。
    输出：所选记录和非负组合权重。最优单配置始终放在首位。
    低相关性仅提供互补机会，最终以训练侧组合 MAE 判断是否加入。
    """
    from .transport import convex_weights
    usable=sorted((r for r in results if r['status']=='complete'),key=lambda r:r['cv_mae'])
    if not usable:return [],np.array([])
    _,gi,counts=np.unique(groups,return_inverse=True,return_counts=True)
    sw=1/counts[gi];sw/=sw.sum()
    selected=[usable[0]];weights=np.ones(1)
    pred=np.asarray(selected[0]['oof']);loss=float(sw@abs(pred-y))
    # 候选质量门槛避免仅为降低相关性引入明显失准的模型。
    remaining=[r for r in usable[1:] if r['cv_mae']<=usable[0]['cv_mae']*1.35]
    while len(selected)<k and remaining:
        best=None
        for r in remaining:
            p=np.column_stack([s['oof'] for s in selected]+[r['oof']])
            w=convex_weights(p,y,groups,.01,prior='best')
            score=float(sw@abs(p@w-y))
            if score<loss-1e-5*max(np.std(y),1e-9) and (best is None or score<best[0]):best=(score,r,w)
        if best is None:break
        loss,r,weights=best;selected.append(r);remaining=[a for a in remaining if a is not r]
    return selected,weights


def load_dataset(path):
    """用途：读取用户提供的数值数据。
    输入：NPZ 路径；必需字段为 x、y、groups，可选 feature_names、ids。
    输出：数据字典；不允许依赖 pickle 的对象数组，分组必须明确提供。
    """
    with np.load(path, allow_pickle=False) as data:
        required = {'x', 'y', 'groups'}
        if not required.issubset(data.files):
            raise ValueError('Dataset requires x, y and groups arrays')
        out = {key: data[key] for key in data.files}
    x, y = np.asarray(out['x'], float), np.asarray(out['y'], float)
    groups = np.asarray(out['groups']).astype(str)
    if x.ndim != 2 or y.shape != (len(x),) or groups.shape != (len(x),):
        raise ValueError('Dataset array shapes are inconsistent')
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('Dataset contains nonfinite values')
    out.update(x=x, y=y, groups=groups)
    out.setdefault('feature_names', np.array([f'x{i}' for i in range(x.shape[1])]))
    out.setdefault('ids', np.arange(len(x)).astype(str))
    if len(out['ids']) != len(x) or len(out['feature_names']) != x.shape[1]:
        raise ValueError('Dataset metadata lengths are inconsistent')
    return out


def evaluate_dataset(data_path, output, seed=1729, n_splits=3, policy=None):
    """用途：在独立外层分组折上评估完整自动选模流程。
    输入：data_path 为 NPZ；output 是空输出目录；seed、n_splits 控制外层划分；
    policy=None 使用完整冻结池。每折使用全部外层训练行。
    输出：保存逐折训练/测试索引、决策、预测和 MAE，返回汇总字典。
    外层测试标签仅用于已固定模型的误差计算。
    """
    from .api import PARENARegressor
    data = load_dataset(data_path)
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise ValueError('Choose an empty output directory to keep evaluation runs separate')
    if n_splits < 2:
        raise ValueError('n_splits must be at least 2')
    splits = folds(data['groups'], seed, n_splits)
    if any(len(tr) < 12 or len(np.unique(data['groups'][tr])) < 3 for tr, _ in splits):
        raise ValueError('Each outer training fold requires >=12 rows and >=3 independent groups')
    output.mkdir(parents=True, exist_ok=True)
    active_policy = load_policy() if policy is None else policy
    safe_save(output/'policy.json', active_policy)
    safe_save(output/'split_plan.json', dict(
        input_sha256=hashlib.sha256(Path(data_path).read_bytes()).hexdigest(), seed=seed,
        n_splits=len(splits), folds=[dict(train=tr.tolist(), test=te.tolist()) for tr, te in splits]))
    records, all_predictions, truths = [], {}, []
    for f, (tr, te) in enumerate(splits):
        folder = output/f'fold_{f}'
        model = PARENARegressor(random_state=seed+f*101, policy=active_policy)
        model.fit(data['x'][tr], data['y'][tr], groups=data['groups'][tr],
                  feature_names=data['feature_names'].tolist())
        model.export_diagnostics(folder/'decision_before_test.json')
        predictions = {'PARENA_auto': model.predict(data['x'][te])}
        for branch in model.diagnostics_['branch_names']:
            predictions[branch+'_ensemble'] = model.predict_branch(data['x'][te], branch)
            predictions[branch+'_best'] = model.predict_branch(data['x'][te], branch, single=True)
        truth = data['y'][te]
        scores = {name: float(np.mean(abs(p-truth))) for name, p in predictions.items()}
        np.savez_compressed(folder/'predictions.npz', train_indices=tr, test_indices=te,
                            truth=truth, test_groups=data['groups'][te], **predictions)
        record = dict(fold=f, real_train_rows=len(tr), test_rows=len(te),
                      train_groups=len(np.unique(data['groups'][tr])), mae=scores)
        records.append(record)
        for name, p in predictions.items():
            all_predictions.setdefault(name, []).append(p)
        truths.append(truth)
        safe_save(folder/'metrics.json', record)
        print(f'Completed outer fold {f+1}/{len(splits)}', flush=True)
    truth = np.concatenate(truths)
    summary = dict(
        version=active_policy['version'], seed=seed, total_rows=len(data['y']),
        independent_groups=len(np.unique(data['groups'])), folds=records,
        pooled_mae={name: float(np.mean(abs(np.concatenate(p)-truth))) for name, p in all_predictions.items()},
        mean_fold_mae={name: float(np.mean([r['mae'][name] for r in records])) for name in all_predictions},
        interpretation='Outer held-out predictions; all model selection uses the corresponding training fold',
    )
    safe_save(output/'summary.json', summary)
    return summary


def main():
    """用途：提供安装后的 parena-evaluate 命令。
    输入：命令行 --data、--output，及可选 --seed、--folds、--policy。
    输出：运行外层分组评估并打印汇总；输出目录由用户指定。
    """
    parser = argparse.ArgumentParser(description='Grouped outer evaluation of PARENA')
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=1729)
    parser.add_argument('--folds', type=int, default=3)
    parser.add_argument('--policy', type=Path)
    args = parser.parse_args()
    policy = json.loads(args.policy.read_text('utf8')) if args.policy else None
    result = evaluate_dataset(args.data, args.output, args.seed, args.folds, policy)
    print(json.dumps(result['pooled_mae'], indent=2))


if __name__ == '__main__':
    main()

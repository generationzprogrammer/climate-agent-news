"""PARENA 公共接口：自动选模回归与训练内分组评估。"""
from .api import PARENARegressor
from .search import PARENASearch
from .classification import PARENAClassifier

__all__ = ["PARENARegressor", "PARENASearch", "PARENAClassifier"]
__version__ = "0.4.1"

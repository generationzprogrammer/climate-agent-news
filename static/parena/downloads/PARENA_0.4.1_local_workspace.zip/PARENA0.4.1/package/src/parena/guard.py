"""给 auto 增加可选的异常外推回退，保留主模型的训练内选择。

范围由训练标签确定。超出宽松范围的预测改用训练内验证最好的普通树模型。
该机制用于处理明显的数值外推，不能替代误差区间或适用域验证。
本次研究将其作为主方案冻结后的补充分析，原始 auto 结果同时保留。
"""
from copy import deepcopy
import numpy as np
from .api import PARENARegressor
from .transport import fit
from .estimators import digest


class PARENAGuardedRegressor(PARENARegressor):
    """用途：在 auto 预测发生极端外推时，自动切换到普通树模型。
    输入：与 PARENARegressor 相同；mode 必须为 auto。
    输出：predict 给出回退后的预测；guard_diagnostics_ 记录范围和触发次数。
    """

    def fit(self, X, y, groups=None, feature_names=None):
        """用途：拟合原始 auto，并仅用训练数据确定回退模型和触发范围。
        输入：X、y、groups、feature_names 与基础接口含义一致。
        输出：返回 self；额外成本至多为一个普通树模型的全训练集拟合。
        """
        if self.mode!='auto':raise ValueError('Extrapolation fallback requires mode=auto')
        super().fit(X,y,groups=groups,feature_names=feature_names)
        return self._fit_fallback()

    @classmethod
    def from_fitted(cls, model):
        """用途：复用已拟合 auto 的选择结果和模型，添加回退层。
        输入：model 为已拟合的 PARENARegressor(mode='auto')。
        输出：新的回退模型；基础预测模型共享引用，主模型的诊断表保持独立。
        """
        if getattr(model,'mode',None)!='auto' or not hasattr(model,'diagnostics_'):
            raise ValueError('Need a fitted auto model')
        obj=cls(**model.get_params(deep=False));obj.__dict__.update(model.__dict__)
        obj.diagnostics_=deepcopy(model.diagnostics_)
        return obj._fit_fallback()

    def _fit_fallback(self):
        """用途：从已有折外记录选普通树模型，并建立宽松的训练响应范围。
        输入：使用已保存的训练上下文与 Original 候选记录。
        输出：保存 fallback_model_、response_bounds_ 和回退诊断，不读取测试值。
        """
        rows=self.diagnostics_['branches']['Original']['candidate_scores']
        eligible=[r for r in rows if r['config']['model']['kind'] in ['et','cat','rf','hist']
                  and not r['config'].get('residual_model',False)
                  and np.isfinite(r.get('cv_mae',np.nan))]
        if not eligible:raise ValueError('Policy needs a finite-CV plain tree candidate in Original')
        order={'cat':0,'et':1,'rf':2,'hist':3}
        chosen=min(eligible,key=lambda r:(r['cv_mae'],order[r['config']['model']['kind']]));cfg=chosen['config'];model=None
        spec=self.diagnostics_['branches']['Original']
        for candidate,trained in zip(spec['configs'],self.branch_models_['Original'].models):
            if digest(candidate)==digest(cfg):model=trained;break
        ctx=self._training_context
        self.fallback_model_=fit(ctx,cfg) if model is None else model
        span=max(float(np.ptp(ctx.y)),6*float(np.std(ctx.y)),1e-12)
        self.response_bounds_=(float(ctx.y.min()-span),float(ctx.y.max()+span))
        self.training_response_median_=float(np.median(ctx.y))
        self.guard_diagnostics_=dict(bounds=list(self.response_bounds_),span=span,
            fallback_config=deepcopy(cfg),fallback_cv_mae=float(chosen['cv_mae']),
            rule='Outside [min(y)-s,max(y)+s], s=max(range(y),6*std(y)), or nonfinite',
            last_query_count=0,last_triggered_count=0,uncertainty='Numerical extrapolation rule; not calibrated uncertainty')
        self.diagnostics_['extrapolation_guard']=self.guard_diagnostics_
        ctx.cache.clear();ctx._teacher=None
        return self

    def predict(self, X):
        """用途：预测并对极端外推执行回退。
        输入：X 为与训练列定义一致的二维数值表。
        输出：一维预测；被触发的行使用普通树模型，仍异常时使用训练标签中位数。
        """
        x=self._validate_query(X);raw=super().predict(x)
        lower,upper=self.response_bounds_;triggered=(~np.isfinite(raw))|(raw<lower)|(raw>upper)
        if triggered.any():
            fallback=np.asarray(self.fallback_model_.predict(x[triggered]),float)
            bad=(~np.isfinite(fallback))|(fallback<lower)|(fallback>upper)
            fallback[bad]=self.training_response_median_;raw=raw.copy();raw[triggered]=fallback
        self.guard_diagnostics_.update(last_query_count=len(raw),last_triggered_count=int(triggered.sum()))
        return raw

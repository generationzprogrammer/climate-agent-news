"""当前 PARENA 核心的邻域与真实差值学习。

训练内计算加权距离、动态选择参考样本、学习实测样本对的性质差异，并组合预测。"""
import time
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import ExtraTreesRegressor
from catboost import CatBoostRegressor, Pool
from .estimators import save, RiskAwarePairModel, Augmented, Context, folds
from scipy.optimize import minimize, linprog
from scipy import sparse
import warnings

def safe_save(path,obj):
    """用途：以临时文件方式保存 JSON，并短暂重试文件占用错误。
    输入：path 为目标路径；obj 为可序列化对象。
    输出：写入文件，返回值与底层 save 一致。"""
    for i in range(30):
        try:return save(path,obj)
        except PermissionError:
            if i==29:raise
            time.sleep(.05*(i+1))

class Geometry:
    """用途：按训练数据拟合参考样本之间的距离表示。
    输入：ctx 为当前训练折；cfg 指定 importance、response 或 shap 几何。
    输出：提供 transform 和 distance 方法。"""
    def __init__(self,ctx,cfg):
        """用途：确定距离表示所需的变量权重和可选响应模型。
        输入：ctx 为训练上下文；cfg 为候选配置。
        输出：初始化后的对象保存训练样本变换结果。"""
        self.ctx=ctx;self.cfg=cfg;self.scale=ctx.scale
        kind=cfg.get('geometry','importance');self.kind=kind
        self.imp=ctx.importance if kind!='uniform' else np.ones(ctx.x.shape[1])/ctx.x.shape[1]
        self.model=None;self.guide=None
        if kind=='shap':
            key=('geometry_shap_model',)
            if key not in ctx.cache:
                ctx.cache[key]=CatBoostRegressor(iterations=160,depth=3,learning_rate=.055,l2_leaf_reg=10,thread_count=1,random_seed=ctx.seed,verbose=False,allow_writing_files=False).fit(ctx.x,ctx.y)
            self.model=ctx.cache[key]
        elif kind=='response':self.guide=ctx.guide()
        key=('geometry_training_coordinates',kind)
        if key not in ctx.cache:ctx.cache[key]=self.transform(ctx.x)
        self.train=ctx.cache[key]
    def transform(self,x):
        """用途：把原始特征变成计算距离用的坐标。
        输入：x 为二维数值特征；列顺序与训练时相同。
        输出：返回加权标准化坐标；响应版或 SHAP 版会追加训练得到的响应坐标。"""
        z=self.scale.transform(x)*np.sqrt(self.imp)
        if self.kind=='shap':
            phi=self.model.get_feature_importance(Pool(x),type='ShapValues')[:,:-1]/self.ctx.sd
            return np.c_[z*np.sqrt(.5),phi*np.sqrt(.5)]
        if self.kind=='response':return np.c_[z*np.sqrt(.5),self.guide.predict(x)/self.ctx.sd*np.sqrt(.5)]
        return z
    def distance(self,a,b=None):
        """用途：计算查询样本到参考样本的欧氏距离。
        输入：a 为查询特征；b 可选，缺省时使用训练样本。
        输出：返回距离矩阵，每行对应一个查询样本。"""
        return cdist(self.transform(a),self.train if b is None else self.transform(b))

def adaptive_neighbors(d,q=.9,radius=1.,exclude_self=False,mode='mass',max_anchors=None):
    """用途：按局部距离尺度给参考样本加权，并自适应决定邻居数。
    输入：d 为距离矩阵；q 为累计权重门槛；radius 缩放局部带宽；mode 可选择全部参考样本。
    输出：返回每个查询样本的邻居索引和归一化权重。"""
    d=np.asarray(d).copy()
    if exclude_self:np.fill_diagonal(d,np.inf)
    out=[]
    for row in d:
        order=np.argsort(row,kind='stable');order=order[np.isfinite(row[order])]
        if not len(order):out.append((np.array([],int),np.array([])));continue
        if mode=='all':out.append((order,np.full(len(order),1/len(order))));continue
        # 用附近训练样本的距离确定局部带宽；邻居数随位置变化。
        local=min(len(order),max(2,int(np.ceil(np.sqrt(len(order))))))
        bw=max(float(np.median(row[order[:local]]))*radius,1e-8)
        # 距离越近，参考样本的初始投票权重越高。
        p=np.exp(-np.minimum((row[order]-row[order[0]])/bw,700));p/=p.sum()
        k=min(len(order),int(np.searchsorted(np.cumsum(p),q))+1)
        if max_anchors is not None:k=min(k,int(max_anchors))
        out.append((order[:k],p[:k]/p[:k].sum()))
    return out

class PairTransport:
    """用途：从真实训练样本对学习性质差异，并对新样本汇总邻居投票。
    输入：ctx 是训练折；cfg 控制距离、成对学习器和邻域规则。
    输出：predict 返回性质预测；info 保存样本对来源与邻居统计。"""
    def __init__(self,ctx,cfg):
        """用途：构建真实样本对，训练预测差值的 ExtraTrees 或 CatBoost。
        输入：ctx 为真实训练数据；cfg 控制成对数量、响应引导等。
        输出：保存成对模型和父样本索引；不会把样本对当作独立实验。"""
        self.cfg=cfg;self.ctx=ctx;self.x=ctx.x;self.y=ctx.y;self.sd=ctx.sd;self.scale=ctx.scale
        self.geo=Geometry(ctx,cfg);self.guide=ctx.guide(cfg.get('guide_form','spline')) if cfg.get('guide',False) else None
        self.r=ctx.y-(self.guide.predict(ctx.x) if self.guide is not None else 0)
        imp=ctx.importance;order=np.argsort(-imp,kind='stable')
        coverage=cfg.get('coverage',1.)
        nactive=min(len(imp),int(np.searchsorted(np.cumsum(imp[order]),coverage))+1)
        self.active=order[:nactive] if coverage<1 else np.arange(len(imp))
        # 大训练集按行分块计算距离，避免保存 n×n 距离矩阵。
        hood=[]
        for start in range(0,ctx.n,128):
            dd=cdist(self.geo.train[start:start+128],self.geo.train)
            dd[np.arange(len(dd)),np.arange(start,start+len(dd))]=np.inf
            hood.extend(adaptive_neighbors(dd,cfg.get('q',.9),cfg.get('radius',1.),False,'all' if cfg.get('global_pairs',False) else 'mass',cfg.get('max_anchors')))
        self.anchor_reliability=np.ones(ctx.n)
        if cfg.get('anchor_reliability',False):
            key=('anchor_guide_oof_reliability',cfg.get('guide_form','spline'))
            if key not in ctx.cache:
                errors=np.empty(ctx.n)
                for f,(tr,va) in enumerate(folds(ctx.groups,ctx.seed+419)):
                    inner=Context(ctx.raw_x[tr],ctx.y[tr],ctx.groups[tr],ctx.seed+f+419,ctx.names,ctx.standardize)
                    errors[va]=abs(inner.guide(cfg.get('guide_form','spline')).predict(inner.preprocessor.transform(ctx.raw_x[va]))-ctx.y[va])
                scale=max(float(np.median(errors)),.05*ctx.sd,1e-9)
                ctx.cache[key]=.25+.75/(1+(errors/scale)**2)
            self.anchor_reliability=ctx.cache[key]
        rng=np.random.default_rng(ctx.seed+516);edges=[]
        per=cfg.get('pairs_per_point',24)
        for i,(ix,w) in enumerate(hood):
            if not len(ix):continue
            ix=rng.choice(ix,size=min(len(ix),per),replace=False,p=w)
            edges.extend((i,int(j)) for j in ix)
        if cfg.get('class_boundary_pairs',False):
            # 类别内部邻居的差值可能全为零；补充每行最近的两个异类参考点。
            # 使用当前训练折的类别指示变量，不读取验证/测试标签。
            for start in range(0,ctx.n,128):
                dd=cdist(self.geo.train[start:start+128],self.geo.train)
                for offset,row in enumerate(dd):
                    i=start+offset;opposite=np.flatnonzero(ctx.y!=ctx.y[i])
                    js=opposite[np.argsort(row[opposite],kind='stable')[:2]]
                    edges.extend((i,int(j)) for j in js)
            edges=list(dict.fromkeys(edges))
        # 同一真实样本对保留两个方向，差值标签对应取反。
        edges=np.array(edges,int);edges=np.vstack([edges,edges[:,::-1]])
        a,b=edges.T;v=self.representation(self.x[a],self.x[b],self.geo.train[a],self.geo.train[b]);self.ps=StandardScaler().fit(v)
        c=cfg.get('model',dict(kind='et',leaf=3))
        if c['kind']=='cat':self.model=CatBoostRegressor(iterations=c.get('iterations',240),depth=c.get('depth',4),learning_rate=.055,l2_leaf_reg=5,loss_function=c.get('loss','RMSE'),thread_count=1,random_seed=ctx.seed,verbose=False,allow_writing_files=False)
        else:self.model=ExtraTreesRegressor(n_estimators=c.get('trees',120),min_samples_leaf=c.get('leaf',3),max_features=c.get('max_features',1.),n_jobs=1,random_state=ctx.seed)
        targets=(self.r[a]-self.r[b])/self.sd
        if np.ptp(targets)<1e-12:
            from sklearn.dummy import DummyRegressor
            self.model=DummyRegressor(strategy='constant',constant=float(targets[0]))
        self.model.fit(self.ps.transform(v),targets)
        self.info=dict(pair_count=len(edges),parents=edges.tolist(),active_indices=self.active.tolist(),importance=imp.tolist(),geometry=self.geo.kind,guide=self.guide.export(ctx.names) if self.guide is not None else None,geometry_guide=self.geo.guide.export(ctx.names) if self.geo.guide is not None else None,label='guide-residual difference' if self.guide is not None else 'exact observed difference',unique_real_count=ctx.n,anchor_reliability=self.anchor_reliability.tolist(),max_anchors=cfg.get('max_anchors'))
    def representation(self,a,b,geometry_a=None,geometry_b=None):
        """用途：构造两个样本之间供成对模型使用的输入。
        输入：a、b 是行数相同的数值特征表。
        输出：返回标准化差值或差值加位置等成对特征。"""
        aa=self.scale.transform(a)[:,self.active];bb=self.scale.transform(b)[:,self.active]
        kind=self.cfg.get('representation','diff')
        if kind=='diff':return aa-bb
        if kind=='concat':return np.c_[aa,bb,aa-bb]
        if kind=='response_diff':
            ga=self.geo.transform(a) if geometry_a is None else geometry_a
            gb=self.geo.transform(b) if geometry_b is None else geometry_b
            return np.c_[aa-bb,ga-gb]
        return np.c_[aa-bb,(aa+bb)/2]
    def predict(self,x):
        """用途：用多个真实参考样本的标签与预测差值投票。
        输入：x 为待预测特征表。
        输出：返回每行一个预测值，并更新 info 中的实际邻居数量。"""
        x=np.asarray(x,float);result=[];counts=[];effective=[]
        # 分批预测以限制内存使用；固定分批方式保证结果可复现。
        batch=max(1,min(128,16384//max(1,min(len(self.x),self.cfg.get('max_anchors',len(self.x))))))
        for start in range(0,len(x),batch):
            xx=x[start:start+batch];gx=self.geo.transform(xx);dist=cdist(gx,self.geo.train)
            hood=adaptive_neighbors(dist,self.cfg.get('q',.9),self.cfg.get('radius',1.),mode='all' if self.cfg.get('global_prediction',False) else 'mass',max_anchors=self.cfg.get('max_anchors'))
            if self.cfg.get('anchor_reliability',False):
                hood=[(ix,(w*self.anchor_reliability[ix])/np.sum(w*self.anchor_reliability[ix])) for ix,w in hood]
            qi=[];ai=[];slices=[];pos=0
            for j,(ix,w) in enumerate(hood):qi.extend([j]*len(ix));ai.extend(ix);slices.append((pos,pos+len(ix),w));pos+=len(ix)
            qi=np.array(qi);ai=np.array(ai);aa=xx[qi];bb=self.x[ai]
            p=self.model.predict(self.ps.transform(self.representation(aa,bb,gx[qi],self.geo.train[ai])))
            m=self.model.predict(self.ps.transform(self.representation(bb,aa,self.geo.train[ai],gx[qi])))
            # 正反两个方向的差值取反对称部分，降低方向不一致。
            votes=self.r[ai]+.5*(p-m)*self.sd
            for lo,hi,w in slices:
                v=votes[lo:hi]
                if self.cfg.get('consistency',False):
                    med=np.median(v);sc=max(1.4826*np.median(abs(v-med)),.1*self.sd)
                    w=w/(1+((v-med)/sc)**2);w/=w.sum()
                result.append(float(w@v));counts.append(len(w));effective.append(float(1/(w@w)))
        if counts:self.info['neighbors']=dict(min=int(min(counts)),median=float(np.median(counts)),max=int(max(counts)),effective_median=float(np.median(effective)),at_computational_cap_fraction=float(np.mean(np.array(counts)==self.cfg.get('max_anchors',-1))))
        out=np.array(result)
        return out+(self.guide.predict(x) if self.guide is not None else 0)

def _fit_processed(ctx,cfg):
    """用途：按照候选配置把训练上下文派发到相应模型。
    输入：ctx 为训练折；cfg 的 family 指定 pair_transport、risk_pair 或 pseudo 等。
    输出：返回已拟合的模型对象。"""
    kind=cfg.get('family','pair_transport')
    if kind=='pair_transport':return PairTransport(ctx,{k:v for k,v in cfg.items() if k!='family'})
    if kind=='risk_pair':return RiskAwarePairModel(ctx,{k:v for k,v in cfg.items() if k!='family'},'PARENA_Pair')
    if kind=='pseudo':return Augmented(ctx,{k:v for k,v in cfg.items() if k!='family'},'PARENA')
    if kind in ['Original','Mixup','CMixup']:
        return Augmented(ctx,{k:v for k,v in cfg.items() if k!='family'},kind)
    raise ValueError(f'Unknown candidate family: {kind}')

def convex_weights(pred,y,groups=None,regularization=.01,prior='uniform'):
    """用途：用训练内折外预测拟合非负、和为一的组合权重。
    输入：pred 为样本乘模型的预测矩阵；y 为真实训练目标；groups 用于分组加权。
    输出：返回每个模型的组合权重，不使用外层测试标签。"""
    pred=np.asarray(pred);n,m=pred.shape;sd=max(np.std(y),1e-9)
    if m==1:return np.ones(1)
    weights=np.ones(n)/n
    if groups is not None:
        _,ix,counts=np.unique(groups,return_inverse=True,return_counts=True)
        weights=1/counts[ix];weights/=weights.sum()
    center=np.full(m,1/m) if prior=='uniform' else np.eye(m)[np.argmin(weights@abs(pred-y[:,None]))]
    if prior=='best':
        # 在单纯形上 ||w-e_best||_1 = 2(1-w_best)，可精确写成稀疏线性规划。
        # 与 MAE 一致的目标同时鼓励稀疏组合，降低无收益成员的预测开销。
        z=(pred-np.mean(y))/sd;target=(y-np.mean(y))/sd
        A=sparse.vstack([sparse.hstack([sparse.csr_matrix(z),-sparse.eye(n)]),
                         sparse.hstack([-sparse.csr_matrix(z),-sparse.eye(n)])],format='csr')
        objective=np.r_[-2*regularization*center,weights]
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore',message='Unrecognized options detected.*')
            solution=linprog(objective,A_ub=A,b_ub=np.r_[target,-target],
                A_eq=sparse.csr_matrix(np.r_[np.ones(m),np.zeros(n)][None,:]),b_eq=[1.],
                bounds=[(0,1)]*m+[(0,None)]*n,method='highs-ds',options={'threads':1,'presolve':True})
        if not solution.success:return center
        w=np.clip(solution.x[:m],0,1);w[w<1e-10]=0
        return w/w.sum()
    def obj(w):
        """用途：计算给定权重下的分组 MAE 与均匀权重收缩惩罚。
        输入：w 为待优化的模型权重。
        输出：返回标量目标值，供 SLSQP 优化。"""
        return float(weights@abs(pred@w-y)/sd+regularization*np.sum((w-center)**2))
    out=minimize(obj,center,method='SLSQP',bounds=[(0,1)]*m,constraints={'type':'eq','fun':lambda w:w.sum()-1},options={'maxiter':250,'ftol':1e-10})
    w=np.clip(out.x,0,1)
    if not np.isfinite(w).all() or w.sum()<1e-9:return np.eye(m)[np.argmin(np.mean(abs(pred-y[:,None]),axis=0))]
    return w/w.sum()

class Ensemble:
    """用途：保存多个已训练模型及其组合权重。
    输入：models 为模型序列；weights 为对应非负权重。
    输出：predict 返回加权预测。"""
    def __init__(self,models,weights):
        """用途：保存组合模型和权重。
        输入：models 与 weights 按相同顺序对应。
        输出：返回值为 None。"""
        self.models=models;self.weights=np.array(weights)
    def predict(self,x):
        """用途：将各子模型预测按权重求和。
        输入：x 为待预测特征表。
        输出：返回每行一个加权预测值。"""
        active=np.flatnonzero(self.weights>0)
        return np.column_stack([self.models[i].predict(x) for i in active])@self.weights[active]


def fit(ctx, cfg):
    """在当前训练折处理缺失/异常数据，再拟合候选；返回接收原始特征的模型。"""
    from .preprocessing import PreparedModel
    original = ctx
    keep = np.arange(ctx.n)
    if ctx.remove_outliers:
        keep = np.flatnonzero(~ctx.preprocessor.outliers(ctx.raw_x))
        if len(keep) < 12 or len(np.unique(ctx.groups[keep])) < 3 or np.std(ctx.y[keep]) < 1e-12:
            raise ValueError('Outlier removal leaves insufficient training data; retain outliers or supply more groups')
        ctx = Context(ctx.raw_x[keep],ctx.y[keep],ctx.groups[keep],ctx.seed,ctx.names,ctx.standardize,False)
    model = _fit_processed(ctx,cfg)
    ans = PreparedModel(model,ctx.preprocessor,keep)
    ans.outlier_rule = original.preprocessor
    return ans

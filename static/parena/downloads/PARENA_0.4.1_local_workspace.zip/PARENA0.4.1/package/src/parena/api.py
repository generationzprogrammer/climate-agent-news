"""PARENA 的用户入口：数值表或 SMILES 输入、训练内选择、预测及结果导出。

PARENARegressor 默认输出 auto 组合预测。predict_branch 可读取各分支结果。
候选配置、预处理和组合权重均使用传给 fit 的训练数据确定。
"""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from contextlib import nullcontext
import time

import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_is_fitted

from .estimators import Context, digest, synthetic
from .study import cv_config, select_diverse, select_complementary, load_policy, baseline_pools
from .transport import Ensemble, convex_weights, fit, safe_save


class PARENARegressor(RegressorMixin, BaseEstimator):
    """用途：在训练内选择候选，并组合 Original、Mixup、CMixup 和 PARENA_core。
    输入：random_state 固定随机过程；task 记录任务用途；policy 可提供候选策略。
    输出：fit 返回已拟合对象，predict 返回 auto 预测，diagnostics_ 保存选择依据。
    task 是用途标记；特征形式由数值输入或 fit_smiles 决定。
    """

    def __init__(self, random_state=728, task='property_prediction', policy=None, cache_dir=None, mode='auto', standardize=False, remove_outliers=False):
        """用途：保存构造参数。
        输入：policy=None 使用包内冻结候选池；mode='core' 只训练核心分支，
        mode='auto' 同时比较基础方法；cache_dir 可指定本地断点缓存目录。
        输出：返回值为 None；实例创建时不执行计算。
        """
        self.random_state = random_state
        self.task = task
        self.policy = policy
        self.cache_dir = cache_dir
        self.mode = mode
        self.standardize = standardize
        self.remove_outliers = remove_outliers

    def fit(self, X, y, groups=None, feature_names=None):
        """用途：通过训练内三折分组验证选择候选、拟合分支及组合权重。
        输入：X 为 n×p 数值特征，y 为 n 个真实标签；groups 为不能跨折的实体标识；
        feature_names 为 p 个特征名。同一分子、配方或关联实验应共享分组。
        输出：返回 self，保存 branch_models_、model_ 和 diagnostics_。
        调用者应预先留出独立测试集，仅把开发集传入此函数。
        """
        allowed = ['property_prediction', 'formulation_prediction', 'candidate_ranking']
        if self.task not in allowed:
            raise ValueError(f'Supported tasks: {allowed}')
        if self.mode not in ['auto','core']:raise ValueError('mode must be auto or core')
        X, y = np.asarray(X, float), np.asarray(y, float)
        if X.ndim != 2 or y.ndim != 1 or len(X) != len(y) or len(y) < 12 or X.shape[1] == 0:
            raise ValueError('Need a numeric 2D table, matching 1D labels and at least 12 rows')
        if not np.isfinite(y).all():
            raise ValueError('Training targets must be finite; reserve unlabeled rows for prediction')
        if not any(np.ptp(c[np.isfinite(c)]) > 1e-10 for c in X.T if np.isfinite(c).any()):
            raise ValueError('At least one varying feature is required')
        if np.std(y) < 1e-12:
            raise ValueError('A varying target is required for candidate learning')
        g = np.arange(len(y)).astype(str) if groups is None else np.asarray(groups).astype(str)
        if g.ndim != 1 or len(g) != len(y) or len(np.unique(g)) < 3:
            raise ValueError('Need at least three independent groups, one group identifier per row')
        names = list(feature_names) if feature_names is not None else [f'x{i}' for i in range(X.shape[1])]
        if len(names) != X.shape[1] or len(set(names)) != len(names) or not all(isinstance(n, str) for n in names):
            raise ValueError('Feature names must be unique strings, one per input column')
        self.feature_names_in_ = names
        self.n_features_in_ = X.shape[1]
        self.training_min_ = np.array([np.min(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in X.T])
        self.training_max_ = np.array([np.max(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in X.T])
        self.policy_ = load_policy() if self.policy is None else deepcopy(self.policy)
        pools = baseline_pools(self.policy_).copy()
        pools['PARENA_core'] = self.policy_['pool']
        if self.mode=='core':pools={'PARENA_core':self.policy_['pool']}
        if any(not pool for pool in pools.values()):
            raise ValueError('Each branch needs at least one candidate')
        ctx = Context(X, y, g, self.random_state, names, self.standardize, self.remove_outliers)
        selections, models = {}, {}
        manager=TemporaryDirectory(prefix='parena_') if self.cache_dir is None else nullcontext(str(self.cache_dir))
        with manager as tmp:
            for name, pool in pools.items():
                branch_start=time.perf_counter();branch_cpu=time.process_time()
                rows = [cv_config(ctx, c, Path(tmp)/f'{digest(c)}.json') for c in pool]
                if self.policy_.get('ensemble')=='complementary':
                    chosen,w = select_complementary(rows,y,g)
                else:
                    chosen = select_diverse(rows)
                    w = convex_weights(np.column_stack([r['oof'] for r in chosen]),y,g) if chosen else np.array([])
                if not chosen:
                    raise ValueError(f'No eligible configuration for branch {name}')
                p = np.column_stack([r['oof'] for r in chosen])
                search_seconds=time.perf_counter()-branch_start;search_cpu=time.process_time()-branch_cpu
                refit_start=time.perf_counter();refit_cpu=time.process_time()
                models[name] = Ensemble([fit(ctx, r['config']) for r in chosen], w)
                selections[name] = dict(
                    configs=[r['config'] for r in chosen], weights=w.tolist(),
                    oof=(p@w).tolist(), cv_mae=float(np.mean(abs(p@w-y))),
                    candidate_count=len(rows),
                    candidate_scores=[{k: r[k] for k in ['config', 'status', 'cv_mae', 'fold_mae', 'fold_preprocessing', 'reason'] if k in r} for r in rows],
                    selected_config_cv_mae=[r['cv_mae'] for r in chosen],
                    residual_correlation=np.nan_to_num(np.atleast_2d(np.corrcoef((p-y[:,None]).T)),nan=1.).tolist(),
                    search_seconds=search_seconds,search_cpu_seconds=search_cpu,
                    refit_seconds=time.perf_counter()-refit_start,refit_cpu_seconds=time.process_time()-refit_cpu,
                )
        # 分支组合只读取训练内折外预测；PARENA_core 始终是最后一个分支。
        names = list(selections)
        p = np.column_stack([selections[n]['oof'] for n in names])
        w = convex_weights(p, y, g, .01 if self.policy_.get('ensemble')=='complementary' else .03,prior='best' if self.policy_.get('ensemble')=='complementary' else 'uniform')
        baseline_w=convex_weights(p[:,:-1],y,g,.01,prior='best') if len(names)>1 else np.array([])
        self.baseline_auto_=Ensemble([models[n] for n in names[:-1]],baseline_w) if len(names)>1 else None
        self.branch_models_ = models
        self.model_ = Ensemble([models[n] for n in names], w)
        self._training_context = ctx
        self.diagnostics_ = dict(
            version='PARENA 0.4.1', task=self.task,
            preprocessing=dict(missing='training-fold median; all-missing columns zero', standardize=self.standardize, remove_outliers=self.remove_outliers, outlier_rule='training-feature 3 IQR; continuous columns only; test rows retained'),
            mode=self.mode,
            random_state=self.random_state, policy_sha256=digest(self.policy_),
            independent_groups=len(np.unique(g)), real_rows=len(y), feature_count=X.shape[1],
            feature_names=list(self.feature_names_in_),
            branch_names=names, branch_weights=w.tolist(), branches=selections,
            automatic_augmentation_weight=float(w[-1]),
            baseline_auto_weights=baseline_w.tolist(),
            grouping='caller supplied' if groups is not None else 'each row assumed independent; caller must group related observations',
            cv_mae_role='Training-side model selection; use an outer held-out test for performance reporting',
            label_semantics='Pairs and interpolations are dependent training constructs',
        )
        # 内层折模型和伪样本缓存只服务于搜索；拟合后释放，预测模型仍保留所需引用。
        ctx.cache.clear();ctx._teacher=None
        return self

    def _validate_query(self, X):
        """用途：统一检查预测输入的列数与数值。
        输入：X 为待预测二维特征表。
        输出：返回有限数值数组；未拟合或列模式错误时抛出明确异常。
        """
        check_is_fitted(self, ['model_', 'n_features_in_'])
        X = np.asarray(X, float)
        if X.ndim != 2 or X.shape[1] != self.n_features_in_:
            raise ValueError('Feature schema or finiteness mismatch')
        return X

    def predict(self, X):
        """用途：使用 auto 组合预测性质。
        输入：X 的列顺序、单位和特征定义须与训练时一致。
        输出：长度为样本数的一维预测数组，单位与 y 一致。
        """
        X = self._validate_query(X)
        return self.model_.predict(X) if len(X) else np.empty(0)

    def predict_branch(self, X, branch='PARENA_core', single=False):
        """用途：读取某一分支的预测，便于比较核心方法与基础方法。
        输入：branch 选 Original、Mixup、CMixup 或 PARENA_core；single=True 使用
        该分支交叉验证 MAE 最低的单配置，False 使用最多三个配置的分支组合。
        输出：与 X 行对应的预测数组。所有配置与权重已经在 fit 中固定。
        """
        X = self._validate_query(X)
        if branch not in self.branch_models_:
            raise ValueError(f'Unknown branch: {branch}')
        model = self.branch_models_[branch]
        model = model.models[0] if single else model
        return model.predict(X) if len(X) else np.empty(0)

    def rank_candidates(self, X, direction='low'):
        """用途：按照预测性质给已有候选排序。
        输入：X 为候选特征；low 表示优先较小值，high 表示优先较大值。
        输出：排序后的候选行号；此函数不生成分子结构。
        """
        if direction not in ['low', 'high']:
            raise ValueError('direction must be low or high')
        p = self.predict(X)
        return np.argsort(p if direction == 'low' else -p, kind='stable')

    def diagnose(self, X):
        """用途：统计待预测样本超出训练特征范围的程度。
        输入：X 为待检查的数值表。
        输出：字典中的 outside_training_range_fraction 为每行越界变量比例。
        该诊断量未经误差概率校准。
        """
        X = self._validate_query(X)
        return dict(outside_training_range_fraction=np.mean((X < self.training_min_) | (X > self.training_max_), axis=1),
                    caveat='Range diagnostic only; uncalibrated')

    def export_diagnostics(self, path):
        """用途：导出候选比较、所选配置及组合权重。
        输入：path 为 JSON 文件位置。
        输出：写入 JSON，返回值为 None。
        """
        check_is_fitted(self, 'diagnostics_')
        safe_save(path, self.diagnostics_)

    def fit_smiles(self, smiles, y):
        """用途：计算完整 KPI64，按照分子身份分组后调用 fit。
        输入：smiles 为分子字符串序列，y 为相应真实标签。
        输出：返回 self。需要安装 molecule 可选依赖，描述符实现在本包 chemistry.py。
        """
        from .chemistry import kpi64, identity, FEATURE_NAMES
        smiles = list(smiles)
        return self.fit(np.array([kpi64(s) for s in smiles]), y,
                        groups=np.array([identity(s) for s in smiles]), feature_names=FEATURE_NAMES)

    def predict_smiles(self, smiles):
        """用途：将新分子转换为完整 KPI64 后预测。
        输入：smiles 为分子字符串序列；已拟合模型须使用相同 KPI64 列定义。
        输出：与分子顺序一致的预测数组。
        """
        from .chemistry import kpi64, FEATURE_NAMES
        check_is_fitted(self, 'feature_names_in_')
        if list(self.feature_names_in_) != FEATURE_NAMES:
            raise ValueError('This fitted model does not use the KPI64 feature schema')
        smiles = list(smiles)
        return self.predict(np.array([kpi64(s) for s in smiles]).reshape(-1, 64))

    def export_augmented_training(self, folder):
        """用途：导出核心分支的实际训练样本对或虚拟特征向量。
        输入：folder 为输出目录；需要先完成 fit。
        输出：写入 NPZ 和 manifest.json，记录父样本、标签及目标缩放。
        导出内容含传入的训练数据，仅在有数据共享授权时对外提供。
        """
        check_is_fitted(self, 'branch_models_')
        dest = Path(folder)
        dest.mkdir(parents=True, exist_ok=True)
        ctx = self._training_context
        recipes = self.diagnostics_['branches']['PARENA_core']
        records = []
        for j, (cfg, w, model) in enumerate(zip(recipes['configs'], recipes['weights'], self.branch_models_['PARENA_core'].models)):
            if cfg['family'] in ['pair_transport', 'risk_pair']:
                ctx = model.ctx
                parents = np.array(model.info['parents'], int)
                a, b = parents.T
                np.savez_compressed(dest/f'component_{j}_pairs.npz', parents=parents,
                                    observed_difference=ctx.y[a]-ctx.y[b],
                                    training_response_difference=model.r[a]-model.r[b],
                                    normalized_training_target=(model.r[a]-model.r[b])/ctx.sd,
                                    target_scale=ctx.sd, real_x=ctx.x, real_y=ctx.y, real_groups=ctx.groups)
                records.append(dict(component=j, kind='observed pair relationships', count=len(parents), weight=w, independent_real_rows=ctx.n))
            elif cfg['family'] == 'pseudo':
                x, y, weight, info = synthetic(ctx, cfg, 'PARENA')
                training_y = y-model.guide.predict(x) if model.guide is not None else y
                np.savez_compressed(dest/f'component_{j}_virtual_vectors.npz', x=x, y=y,
                                    training_response=training_y, weight=weight, n_real=ctx.n)
                safe_save(dest/f'component_{j}_lineage.json', info)
                records.append(dict(component=j, kind='virtual descriptor vectors', count=len(y)-ctx.n, weight=w, independent_real_rows=ctx.n))
        safe_save(dest/'manifest.json', dict(components=records,
                  grouping_rule='Split original entities before augmentation; keep dependent rows in the same fold'))

"""PARENA 分类扩展：对类别指示变量学习样本对差值，再重建类别概率。

分类接口为 0.4.1 新增。模型与概率温度均由训练内分组验证选择；
最终效果应在独立留出数据中评估。本模块无预训练网络和 GPU 依赖。
"""
import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import log_loss
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.utils.validation import check_is_fitted
from catboost import CatBoostClassifier
from .estimators import Context
from .transport import fit
from .preprocessing import NumericPreprocessor


def probabilities(scores, temperature=1.):
    """把各类别重建值限制到概率范围，归一化后做温度变换。"""
    p=np.clip(np.asarray(scores,float),1e-6,1.)
    p=p**(1/temperature)
    return p/p.sum(axis=1,keepdims=True)


def core_configs():
    """固定的 CPU 分类候选：两种差值学习器；不按测试结果修改。"""
    base=dict(family='pair_transport',geometry='importance',guide=False,class_boundary_pairs=True,
              q=.8,radius=.5,pairs_per_point=16,max_anchors=64)
    return [dict(base,representation='diff',model=dict(kind='et',leaf=2,trees=120)),
            dict(base,representation='diffmid',model=dict(kind='cat',depth=4,iterations=160,loss='RMSE'))]


class ClassCandidate:
    """一个分类候选；core 学习每一类的 0/1 差值，基础候选直接学习类别。"""
    def __init__(self, kind, config=None):
        """保存候选类型和成对学习器配置。"""
        self.kind=kind;self.config=config

    def fit(self,X,y,groups,seed,names,n_classes,standardize,remove_outliers):
        """输入当前训练折；缺失值和可选异常值删除仅在该折内拟合。"""
        self.preprocessor=NumericPreprocessor(standardize).fit(X)
        self.keep=np.flatnonzero(~self.preprocessor.outliers(X)) if remove_outliers else np.arange(len(y))
        if len(self.keep)<12 or len(np.unique(y[self.keep]))!=n_classes:
            raise ValueError('Outlier removal leaves insufficient rows or removes an entire class')
        xx,yy,gg=X[self.keep],y[self.keep],groups[self.keep]
        if self.kind=='core':
            self.models=[]
            for c in range(n_classes):
                ctx=Context(xx,(yy==c).astype(float),gg,seed+c,names,standardize)
                self.models.append(fit(ctx,self.config))
                ctx.cache.clear()
        else:
            self.preprocessor=NumericPreprocessor(standardize).fit(xx)
            self.model=(ExtraTreesClassifier(n_estimators=160,min_samples_leaf=2,n_jobs=1,random_state=seed)
                        if self.kind=='et' else CatBoostClassifier(iterations=160,depth=4,learning_rate=.06,thread_count=1,random_seed=seed,verbose=False,allow_writing_files=False))
            self.model.fit(self.preprocessor.transform(xx),yy)
        return self

    def predict_proba(self,X):
        """输出每行和为一的类别概率，列序对应全局 classes_。"""
        if self.kind=='core':
            return probabilities(np.column_stack([m.predict(X) for m in self.models]))
        return self.model.predict_proba(self.preprocessor.transform(X))


class PARENAClassifier(ClassifierMixin,BaseEstimator):
    """分类入口；mode='core' 使用差值学习，'auto' 可结合基础分类器。

    X 为数值特征（允许缺失），y 为类别，groups 为不可跨折的实体身份。
    predict_proba 返回 n×类别数概率；predict 返回原类别标签。
    """
    def __init__(self,mode='auto',random_state=728,standardize=False,remove_outliers=False):
        """保存模式、随机种子和训练内数据处理选项。"""
        self.mode=mode;self.random_state=random_state
        self.standardize=standardize;self.remove_outliers=remove_outliers

    def fit(self,X,y,groups=None,feature_names=None):
        """训练内三折按 log loss 选择配置及温度；保留完整选择记录。"""
        if self.mode not in ['core','auto']:raise ValueError('mode must be core or auto')
        X=np.asarray(X,float);raw=np.asarray(y)
        if X.ndim!=2 or raw.ndim!=1 or len(X)!=len(raw) or len(X)<18:raise ValueError('Classification needs at least 18 labeled rows')
        if any(v is None or str(v).strip().lower() in ['','nan','none','inf','-inf'] for v in raw):raise ValueError('Class labels must be present and finite')
        self.encoder_=LabelEncoder().fit(raw);y=self.encoder_.transform(raw);self.classes_=self.encoder_.classes_
        nc=len(self.classes_)
        if nc<2 or nc>10:raise ValueError('CPU classification supports 2 to 10 classes')
        g=np.arange(len(y)).astype(str) if groups is None else np.asarray(groups).astype(str)
        if g.shape!=y.shape:raise ValueError('One group per row is required')
        if any(len(np.unique(g[y==c]))<3 for c in range(nc)):raise ValueError('Each class needs at least 3 independent groups for inner validation')
        names=list(feature_names) if feature_names is not None else [f'x{i}' for i in range(X.shape[1])]
        self.n_features_in_=X.shape[1];self.feature_names_in_=names
        fs=list(StratifiedGroupKFold(3,shuffle=True,random_state=self.random_state).split(X,y,g))
        if any(len(np.unique(y[a]))!=nc for a,b in fs):raise ValueError('An inner training fold lacks a class; revise grouping or add class examples')
        candidates=[('core',c) for c in core_configs()]
        if self.mode=='auto':candidates += [('et',None),('cat',None)]
        rows=[];oofs=[]
        for kind,cfg in candidates:
            p=np.empty((len(y),nc))
            for f,(a,b) in enumerate(fs):
                m=ClassCandidate(kind,cfg).fit(X[a],y[a],g[a],self.random_state+f,names,nc,self.standardize,self.remove_outliers)
                p[b]=m.predict_proba(X[b])
            rows.append(dict(kind=kind,config=cfg,log_loss=float(log_loss(y,p,labels=np.arange(nc)))))
            oofs.append(p)
        ci=min(range(2),key=lambda i:rows[i]['log_loss'])
        bi=min(range(2,len(rows)),key=lambda i:rows[i]['log_loss']) if self.mode=='auto' else ci
        trials=[]
        for weight in ([0.,.25,.5,.75,1.] if self.mode=='auto' else [1.]):
            for temp in [.5,1.,2.]:
                p=probabilities(weight*oofs[ci]+(1-weight)*oofs[bi],temp)
                trials.append((float(log_loss(y,p,labels=np.arange(nc))),weight,temp))
        loss,self.core_weight_,self.temperature_=min(trials)
        self.core_=ClassCandidate(*candidates[ci]).fit(X,y,g,self.random_state,names,nc,self.standardize,self.remove_outliers)
        self.base_=ClassCandidate(*candidates[bi]).fit(X,y,g,self.random_state,names,nc,self.standardize,self.remove_outliers) if self.mode=='auto' and self.core_weight_<1 else None
        self.diagnostics_=dict(version='PARENA 0.4.1',task='classification',mode=self.mode,classes=[str(c) for c in self.classes_],
            real_rows=len(y),independent_groups=len(np.unique(g)),candidates=rows,core_weight=self.core_weight_,temperature=self.temperature_,
            selected_oof_log_loss=loss,metric_role='Training-side selection; report held-out performance',
            classification_status='New 0.4.1 extension; independent validation required',random_state=self.random_state,
            standardize=self.standardize,remove_outliers=self.remove_outliers)
        return self

    def predict_proba(self,X):
        """输入原始特征，输出经过训练内温度选择的类别概率。"""
        check_is_fitted(self,'core_');X=np.asarray(X,float)
        if X.ndim!=2 or X.shape[1]!=self.n_features_in_:raise ValueError('Feature schema mismatch')
        p=self.core_.predict_proba(X)
        if self.base_ is not None:p=self.core_weight_*p+(1-self.core_weight_)*self.base_.predict_proba(X)
        return probabilities(p,self.temperature_)

    def predict(self,X):
        """按最大概率给出原始类别名称。"""
        return self.classes_[self.predict_proba(X).argmax(axis=1)]

    def fit_smiles(self,smiles,y):
        """从 SMILES 自动生成 KPI64，并按规范分子身份分组。"""
        from .chemistry import kpi64,identity,FEATURE_NAMES
        smiles=list(smiles)
        return self.fit(np.array([kpi64(s) for s in smiles]),y,groups=[identity(s) for s in smiles],feature_names=FEATURE_NAMES)

    def predict_smiles(self,smiles):
        """对新 SMILES 返回类别。"""
        from .chemistry import kpi64
        return self.predict(np.array([kpi64(s) for s in smiles]))

# PARENA 0.4.1

Pairwise Adaptive Relevance-weighted Estimation with Neighborhood Anchors.

CPU regression and classification with training-side model selection, relevance-weighted neighborhoods and observed response-difference learning.

```python
from parena import PARENARegressor, PARENAClassifier

reg = PARENARegressor(mode="core", random_state=728,
                      standardize=False, remove_outliers=False)
reg.fit(X_train, y_train, groups=entity_groups)
prediction = reg.predict(X_test)

clf = PARENAClassifier(mode="auto", random_state=728)
clf.fit(X_train, class_labels, groups=entity_groups)
probabilities = clf.predict_proba(X_test)
classes = clf.predict(X_test)
```

Keep related observations in the same group and reserve an outer test partition before calling fit. Missing predictors are imputed within each training fold. Targets must be present during fit. SMILES interfaces use the complete KPI64 descriptor set and molecular identity grouping.

The regression full pool preserves the 0.4.0 configurations; classification is newly implemented in 0.4.1 and needs broad external validation. Standardization controls an optional extra input transform; internal distance scaling is always applied. Outlier deletion is optional and applies only to training data.

Install: `python -m pip install -e ".[web,molecule]"`. Web workspace instructions and methodology are in the top-level README and docs directory of the full release archive.

# PARENA 0.4.1：本机分析与公开网页

这个版本将表格读取、数据检查、训练内处理、回归/分类、图表与 PDF 报告连成一个流程。运算在 CPU 上完成。公开网页只提供界面；数据经回环地址交给用户电脑上的 Python 服务。

## 直接使用

1. 解压完整发布包。建议 Python 3.10–3.12。
2. 在此目录运行 `python -m pip install -e "package[web,molecule]"`。
3. Windows 双击 `start_local.cmd`；其他系统运行 `python web/server.py`。
4. 打开终端显示的链接。链接包含本次会话密钥；页面读入后会从地址栏移除。
5. 上传 CSV / XLSX，选目标列与任务，检查特征列，然后开始分析。

网页：https://generationzprogrammer.github.io/climate-agent-news/parena/

浏览器若阻止公开网页访问本机，使用终端显示的 `http://127.0.0.1:8765/` 链接。关闭终端可停止服务。网页无服务器计算替代方案，服务未启动时不能执行模型。

## 新增功能

- `PARENAClassifier`：二分类/多分类，2–10 类。每类建立 0/1 指示变量，使用样本对差值与锚点重建；训练内选择概率温度。auto 可组合 core 与基础分类器。
- `PARENARegressor`：允许缺失/非有限特征；填补规则在每个训练折独立学习。
- `standardize=True/False`：控制额外的模型输入标准化。PARENA 内部距离仍使用标准化坐标。
- `remove_outliers=True/False`：按训练特征 3 IQR 围栏可选删除训练行；测试行全部保留。默认 False。
- 表格或 SMILES → KPI64，提供 64 项定义与示例文件。
- 输出 y/x 分布、响应引导模型 SHAP、训练内拟合的原数据 PCA、真实样本对输入 PCA、留出集预测，以及可下载 PDF/数据包。

## 主要文件

| 文件 | 用途 |
|---|---|
| `package/src/parena/api.py` | 回归接口、训练内选择、core/auto |
| `package/src/parena/classification.py` | 分类差值学习、概率重建、训练内选择 |
| `package/src/parena/preprocessing.py` | 训练内缺失填补与异常值规则 |
| `package/src/parena/transport.py` | 配对训练、动态锚点与预测 |
| `web/analysis.py` | 从数据表到图表、指标和 PDF |
| `web/server.py` | 仅监听本机的计算服务 |
| `web/public/` | 公开静态页面和安全示例 |
| `local_results/` | 用户计算结果，始终留在本机 |
| `docs/0.4.1_方法与验证说明.md` | 方法变化、证据与限制 |

## 输入规则

CSV 使用 UTF-8（也接受 GB18030）；Excel 使用 .xlsx，读取首张表。首行是列名，每行一个样本。上传上限 12 MB，CPU 网页上限 2,000 行、128 个数值特征。数值输入至少 30 条有标签数据和 8 个独立组；分类每类至少 5 个独立组。相关的重复实验、同分子、同配方必须通过分组列保持同组。界面自动把完全相同的特征行合组；用户仍需提供真实实验关系。

SMILES 模式需有效 SMILES；组划分使用保守的分子身份。回归目标必须为有限数值，分类目标为类别。缺失目标行留作预测，不能作为训练标签填补。文本特征需先按合理方案编码。示例：`web/public/samples/`，其中合成回归与合成分子目标示例只用于演示格式，Iris 是公开分类数据。

## 结果与复现

固定 seed=728，约 20% 实体组留出，训练内三折选择。导出记录输入 SHA256、数据划分、预处理规则、选模配置、预测、图表源数据、SHAP 与样本对来源。模型保持拟合于报告中的训练分区；训练行预测标注为 in-sample。一次留出评估用于探索，发表比较应采用预先固定方案、重复独立划分和公平调参预算。

回归完整候选池沿用 0.4.0 的 47 个配置；网页默认交互预算使用 8 个配置（core 2 个、Original/Mixup/CMixup 各 2 个，core 模式只用其中 2 个）。分类 core 两个候选，auto 共四个候选。交互预算结果不可直接替代旧版完整候选池的研究结论。

## 验证命令

```text
python -m unittest discover -s package/tests -p "test_v04*.py"
python package/tests/run_tests.py
python validation/run_integration.py
```

网页开发验证另外使用 Playwright。普通使用无需安装浏览器自动化工具。公开发布不包含 EP 数据、私有研究结果、模型缓存或会话密钥。
